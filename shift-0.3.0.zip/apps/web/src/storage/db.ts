import Dexie, { type Table } from 'dexie';
import { validateDocument, type ShiftDocument } from '@shift/document-model';

export interface StoredDocument { id: string; title: string; updatedAt: number; doc: ShiftDocument }
export interface StoredAsset { id: string; docId: string; name: string; mime: string; blob: Blob }
export interface StoredSnapshot { seq?: number; docId: string; takenAt: number; docUpdatedAt: number; doc: ShiftDocument }
export interface StoredSetting { key: string; value: unknown }

/**
 * Local-first storage. Stores (from the architecture spec): documents, assets,
 * snapshots, settings. `syncQueue` and `recentFiles` are deliberately absent:
 * there is no cloud yet, and "recent" is just documents ordered by updatedAt.
 */
export class ShiftDB extends Dexie {
  documents!: Table<StoredDocument, string>;
  assets!: Table<StoredAsset, string>;
  snapshots!: Table<StoredSnapshot, number>;
  settings!: Table<StoredSetting, string>;

  constructor(name = 'shift') {
    super(name);
    this.version(1).stores({
      documents: 'id, updatedAt',
      assets: 'id, docId',
      snapshots: '++seq, docId, takenAt',
      settings: 'key',
    });
  }
}

export let db = new ShiftDB();
/** Test hook: swap in an isolated database. */
export function useDatabase(next: ShiftDB) { db = next; }

const SNAPSHOTS_PER_DOC = 10;

/** One atomic write: either the whole document lands or nothing does. */
export async function saveDocument(doc: ShiftDocument): Promise<void> {
  await db.documents.put({ id: doc.id, title: doc.title, updatedAt: doc.updatedAt, doc });
}

export async function loadDocument(id: string): Promise<{ ok: true; doc: ShiftDocument } | { ok: false; errors: string[] }> {
  const row = await db.documents.get(id);
  if (!row) return { ok: false, errors: ['Document not found'] };
  return validateDocument(row.doc);
}

export async function listDocuments(): Promise<Array<Pick<StoredDocument, 'id' | 'title' | 'updatedAt'>>> {
  const rows = await db.documents.orderBy('updatedAt').reverse().toArray();
  return rows.map(({ id, title, updatedAt }) => ({ id, title, updatedAt }));
}

export async function deleteDocument(id: string): Promise<void> {
  await db.transaction('rw', db.documents, db.assets, db.snapshots, async () => {
    await db.documents.delete(id);
    await db.assets.where('docId').equals(id).delete();
    await db.snapshots.where('docId').equals(id).delete();
  });
}

// ---- assets ---------------------------------------------------------------

export async function putAsset(a: StoredAsset): Promise<void> { await db.assets.put(a); }
export async function getAsset(id: string): Promise<StoredAsset | undefined> { return db.assets.get(id); }
export async function listAssetsForDoc(docId: string): Promise<StoredAsset[]> { return db.assets.where('docId').equals(docId).toArray(); }

// ---- recovery snapshots ---------------------------------------------------

export async function saveSnapshot(doc: ShiftDocument): Promise<void> {
  await db.transaction('rw', db.snapshots, async () => {
    await db.snapshots.add({ docId: doc.id, takenAt: Date.now(), docUpdatedAt: doc.updatedAt, doc });
    const all = await db.snapshots.where('docId').equals(doc.id).sortBy('seq');
    const extra = all.length - SNAPSHOTS_PER_DOC;
    if (extra > 0) await db.snapshots.bulkDelete(all.slice(0, extra).map((s) => s.seq!));
  });
}

/** A snapshot newer than the stored document means the last save did not complete. */
export async function recoveryCandidate(docId: string): Promise<ShiftDocument | null> {
  const stored = await db.documents.get(docId);
  const snaps = await db.snapshots.where('docId').equals(docId).sortBy('seq');
  const latest = snaps[snaps.length - 1];
  if (!latest) return null;
  if (stored && latest.docUpdatedAt <= stored.updatedAt) return null;
  const v = validateDocument(latest.doc);
  return v.ok ? v.doc : null;
}

// ---- settings -------------------------------------------------------------

export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  const row = await db.settings.get(key);
  return row ? (row.value as T) : fallback;
}
export async function setSetting(key: string, value: unknown): Promise<void> { await db.settings.put({ key, value }); }

// ---- storage health -------------------------------------------------------

export interface StorageStatus { usage: number; quota: number; ratio: number; persisted: boolean; low: boolean }

export async function storageStatus(): Promise<StorageStatus | null> {
  if (typeof navigator === 'undefined' || !navigator.storage?.estimate) return null;
  const { usage = 0, quota = 0 } = await navigator.storage.estimate();
  const persisted = (await navigator.storage.persisted?.()) ?? false;
  const ratio = quota ? usage / quota : 0;
  return { usage, quota, ratio, persisted, low: ratio > 0.8 };
}

/** Ask the browser not to evict our data. Best effort; browsers may decline. */
export async function requestPersistence(): Promise<boolean> {
  try { return (await navigator.storage?.persist?.()) ?? false; } catch { return false; }
}
