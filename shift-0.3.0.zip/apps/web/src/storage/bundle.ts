import {
  fromPrototype, isPrototypeData, validateDocument, uid, type PendingAsset, type ShiftDocument,
} from '@shift/document-model';
import { getAsset, listAssetsForDoc } from './db';

/**
 * Portable backup: one JSON file with the document and its assets as data URLs.
 * A ZIP-based .shift package is planned; this is the dependency-free interim format.
 */
export interface ShiftBundle {
  format: 'shift-bundle';
  bundleVersion: 1;
  exportedAt: number;
  document: ShiftDocument;
  assets: Record<string, { name: string; mime: string; dataUrl: string }>;
}

export async function blobToDataUrl(blob: Blob): Promise<string> {
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return `data:${blob.type || 'application/octet-stream'};base64,${btoa(binary)}`;
}

export async function dataUrlToBlob(dataUrl: string): Promise<Blob> {
  const res = await fetch(dataUrl);
  return res.blob();
}

export async function exportBundle(doc: ShiftDocument): Promise<ShiftBundle> {
  const assets: ShiftBundle['assets'] = {};
  for (const stored of await listAssetsForDoc(doc.id)) {
    if (doc.assets[stored.id]) assets[stored.id] = { name: stored.name, mime: stored.mime, dataUrl: await blobToDataUrl(stored.blob) };
  }
  return { format: 'shift-bundle', bundleVersion: 1, exportedAt: Date.now(), document: doc, assets };
}

export interface ImportResult {
  doc: ShiftDocument;
  assets: Array<{ id: string; name: string; mime: string; blob: Blob }>;
  warnings: string[];
}

/** Accepts a shift-bundle or a prototype (0.1/0.2) export. Always imports as a NEW document id. */
export async function parseImport(text: string): Promise<{ ok: true; result: ImportResult } | { ok: false; error: string }> {
  let data: unknown;
  try { data = JSON.parse(text); } catch (e) { return { ok: false, error: `Not valid JSON: ${(e as Error).message}` }; }
  if (typeof data !== 'object' || data === null) return { ok: false, error: 'File is not a Shift document' };
  const d = data as Record<string, unknown>;

  if (d.format === 'shift-bundle') {
    const b = d as unknown as ShiftBundle;
    const v = validateDocument(b.document);
    if (!v.ok) return { ok: false, error: `Invalid document: ${v.errors.slice(0, 3).join('; ')}` };
    const newId = uid();
    const assets = [];
    for (const [id, a] of Object.entries(b.assets ?? {})) {
      if (v.doc.assets[id]) assets.push({ id, name: a.name, mime: a.mime, blob: await dataUrlToBlob(a.dataUrl) });
    }
    return { ok: true, result: { doc: { ...v.doc, id: newId, updatedAt: Date.now() }, assets, warnings: [] } };
  }

  if (isPrototypeData(data)) {
    const m = fromPrototype(data);
    const assets = await Promise.all(m.assets.map(async (a: PendingAsset) => {
      const blob = await dataUrlToBlob(a.dataUrl);
      return { id: a.assetId, name: a.name, mime: blob.type || 'image/png', blob };
    }));
    return { ok: true, result: { doc: m.doc, assets, warnings: m.warnings } };
  }

  // A bare v1 document
  const v = validateDocument(data);
  if (v.ok) return { ok: true, result: { doc: { ...v.doc, id: uid(), updatedAt: Date.now() }, assets: [], warnings: [] } };
  return { ok: false, error: 'Unrecognised file. Expected a Shift bundle or a prototype export.' };
}

export async function getAssetBlob(id: string): Promise<Blob | null> {
  return (await getAsset(id))?.blob ?? null;
}
