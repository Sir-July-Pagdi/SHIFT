import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { createDocument, createFromTemplate, createObject } from '@shift/document-model';
import {
  ShiftDB, deleteDocument, getSetting, listDocuments, loadDocument, putAsset, recoveryCandidate,
  saveDocument, saveSnapshot, setSetting, useDatabase, listAssetsForDoc,
} from './db';
import { exportBundle, parseImport } from './bundle';

beforeEach(() => { useDatabase(new ShiftDB(`test-${Math.random()}`)); });

describe('document storage', () => {
  it('saves, lists (newest first), loads and deletes', async () => {
    const a = createFromTemplate('lesson').doc;
    const b = { ...createDocument('Second'), updatedAt: a.updatedAt + 1000 };
    await saveDocument(a); await saveDocument(b);
    expect((await listDocuments()).map((d) => d.id)).toEqual([b.id, a.id]);
    const r = await loadDocument(a.id);
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.doc).toEqual(a);
    await deleteDocument(a.id);
    expect((await loadDocument(a.id)).ok).toBe(false);
  });

  it('refuses to load a corrupted stored document instead of returning it', async () => {
    const doc = createDocument();
    await saveDocument(doc);
    const { db } = await import('./db');
    await db.documents.update(doc.id, { doc: { ...doc, objects: { x: { id: 'wrong' } } } as never });
    const r = await loadDocument(doc.id);
    expect(r.ok).toBe(false);
  });

  it('settings round-trip with fallback', async () => {
    expect(await getSetting('reducedMotion', false)).toBe(false);
    await setSetting('reducedMotion', true);
    expect(await getSetting('reducedMotion', false)).toBe(true);
  });
});

describe('recovery snapshots', () => {
  it('offers a snapshot only when it is newer than the stored document', async () => {
    const doc = createDocument();
    await saveDocument(doc);
    await saveSnapshot(doc);
    expect(await recoveryCandidate(doc.id)).toBeNull();
    const newer = { ...doc, title: 'Edited, but save never finished', updatedAt: doc.updatedAt + 5000 };
    await saveSnapshot(newer);
    const rec = await recoveryCandidate(doc.id);
    expect(rec?.title).toBe('Edited, but save never finished');
  });

  it('keeps only the most recent snapshots', async () => {
    const doc = createDocument();
    for (let i = 0; i < 15; i++) await saveSnapshot({ ...doc, updatedAt: doc.updatedAt + i });
    const { db } = await import('./db');
    expect(await db.snapshots.where('docId').equals(doc.id).count()).toBe(10);
  });
});

describe('bundles', () => {
  const png = new Blob([Uint8Array.from([137, 80, 78, 71])], { type: 'image/png' });

  it('exports a document with its assets and imports it as a new document', async () => {
    const doc = createDocument('With image');
    const img = createObject('image', { assetId: 'a1' });
    doc.objects[img.id] = img;
    doc.assets.a1 = { id: 'a1', name: 'pic.png', mime: 'image/png', size: 4 };
    await saveDocument(doc);
    await putAsset({ id: 'a1', docId: doc.id, name: 'pic.png', mime: 'image/png', blob: png });
    const bundle = await exportBundle(doc);
    expect(bundle.assets.a1!.dataUrl.startsWith('data:image/png')).toBe(true);
    const imported = await parseImport(JSON.stringify(bundle));
    expect(imported.ok).toBe(true);
    if (imported.ok) {
      expect(imported.result.doc.id).not.toBe(doc.id);
      expect(imported.result.assets).toHaveLength(1);
      expect(imported.result.assets[0]!.blob.size).toBe(4);
    }
    expect((await listAssetsForDoc(doc.id)).length).toBe(1);
  });

  it('imports a prototype export', async () => {
    const proto = { format: 'SHIFT', version: 1, name: 'Old', objects: [{ id: 'a', type: 'text', x: 1, y: 2, w: 100, h: 40, text: 'hi' }], frames: [], slides: [] };
    const r = await parseImport(JSON.stringify(proto));
    expect(r.ok).toBe(true);
    if (r.ok) expect(Object.values(r.result.doc.objects)[0]!.text).toBe('hi');
  });

  it('rejects junk with a readable error', async () => {
    expect((await parseImport('nope')).ok).toBe(false);
    expect((await parseImport('{"hello":1}')).ok).toBe(false);
    expect((await parseImport('42')).ok).toBe(false);
  });
});
