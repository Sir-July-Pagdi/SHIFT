import { memo, useEffect, useRef } from 'react';
import type { SceneObject, ShiftDocument } from '@shift/document-model';
import { objectsInSpace } from '@shift/engine';
import { useAssetUrl } from '../assets';

interface ObjProps {
  o: SceneObject;
  /** Nesting depth for frames, so inner frames paint (and take clicks) above outer ones. */
  depth: number;
  editing: boolean;
  hideChrome: boolean;
  onCommit?: (id: string, text: string) => void;
}

const FONT = 'system-ui, -apple-system, "Segoe UI", sans-serif';

function ImageBody({ assetId }: { assetId?: string }) {
  const url = useAssetUrl(assetId);
  return url ? <img src={url} alt="" draggable={false} /> : <div className="img-missing" />;
}

function TextEditor({ o, onCommit }: { o: SceneObject; onCommit?: ObjProps['onCommit'] }) {
  const ref = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { ref.current?.focus(); ref.current?.select(); }, []);
  return (
    <textarea
      ref={ref}
      className="inline-editor"
      defaultValue={o.text}
      onBlur={(e) => onCommit?.(o.id, e.target.value)}
      onKeyDown={(e) => {
        e.stopPropagation();
        if (e.key === 'Escape') { e.preventDefault(); onCommit?.(o.id, o.text); }
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); (e.target as HTMLTextAreaElement).blur(); }
      }}
      style={{ fontSize: o.fontSize, color: o.color, fontWeight: o.bold ? 800 : 650 }}
    />
  );
}

const ObjectEl = memo(function ObjectEl({ o, depth, editing, hideChrome, onCommit }: ObjProps) {
  const style: React.CSSProperties = {
    left: o.x, top: o.y, width: o.w, height: o.h, zIndex: o.type === 'frame' ? -100_000_000 + depth * 1_000_000 + Math.max(-500_000, Math.min(500_000, o.z)) : o.z,
    transform: o.rotation ? `rotate(${o.rotation}deg)` : undefined,
    fontFamily: FONT,
  };
  if (o.type === 'text') Object.assign(style, { color: o.color, fontSize: o.fontSize, fontWeight: o.bold ? 800 : 650 });
  if (o.type === 'card') Object.assign(style, { background: o.fill, color: o.color, fontSize: o.fontSize, fontWeight: o.bold ? 800 : 650 });
  if (o.type === 'rect' || o.type === 'circle') Object.assign(style, { background: o.fill, border: o.type === 'circle' ? 'none' : `1px solid ${o.stroke}` });
  if (o.type === 'frame') Object.assign(style, { borderColor: o.stroke, background: o.fill });
  if (o.type === 'frame' && hideChrome) { style.borderColor = 'transparent'; style.background = 'transparent'; }
  return (
    <div className={`obj ${o.type}`} data-id={o.id} data-type={o.type} style={style}>
      {o.type === 'image' ? <ImageBody assetId={o.assetId} /> : null}
      {(o.type === 'text' || o.type === 'card') && !editing ? o.text : null}
      {(o.type === 'text' || o.type === 'card') && editing ? <TextEditor o={o} onCommit={onCommit} /> : null}
      {o.type === 'frame' && !hideChrome ? (
        editing
          ? <input className="frame-label editing" autoFocus defaultValue={o.text}
              onKeyDown={(e) => { e.stopPropagation(); if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); if (e.key === 'Escape') onCommit?.(o.id, o.text); }}
              onBlur={(e) => onCommit?.(o.id, e.target.value)} />
          : <span className="frame-label" data-label>{o.text || 'Topic'}</span>
      ) : null}
    </div>
  );
});

function depthOf(doc: ShiftDocument, o: SceneObject): number {
  let d = 0;
  let p = o.parentId;
  while (p && d < 30) { d++; p = doc.objects[p]?.parentId ?? null; }
  return d;
}

export interface Region { x: number; y: number; w: number; h: number }

interface SceneProps {
  doc: ShiftDocument;
  /** null = canvas */
  slideId: string | null;
  editingId?: string | null;
  hideFrames?: boolean;
  /** Only render objects touching this rectangle (thumbnails, big canvases). */
  region?: Region;
  onCommitText?: (id: string, text: string) => void;
}

/** Renders one space of a document. Shared by the editor, thumbnails and the presenter. */
export function SceneView({ doc, slideId, editingId = null, hideFrames = false, region, onCommitText }: SceneProps) {
  let list = objectsInSpace(doc, slideId);
  if (hideFrames) list = list.filter((o) => o.type !== 'frame');
  if (region) {
    list = list.filter((o) => o.x < region.x + region.w && o.x + o.w > region.x && o.y < region.y + region.h && o.y + o.h > region.y);
  }
  return (
    <>
      {list.map((o) => (
        <ObjectEl key={o.id} o={o} depth={o.type === 'frame' ? depthOf(doc, o) : 0} editing={editingId === o.id} hideChrome={hideFrames} onCommit={onCommitText} />
      ))}
    </>
  );
}
