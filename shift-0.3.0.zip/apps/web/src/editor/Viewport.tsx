import { useEffect, useRef } from 'react';
import type { SceneObject } from '@shift/document-model';
import {
  autoParent, cameraToCss, handleWorldPosition, moveObjects, objectsInSpace, resizeBox, rotationToward, screenToWorld,
  topLevel, updateObject, reparentAll, type HandleId, type Point,
} from '@shift/engine';
import {
  beginGesture, cancelGesture, commitText, endGesture, fitView, liveAdjust, liveUpdate, panScreen, select, setCamera, setViewport,
  useEditor, zoomBy, getDoc,
} from '../store';
import { SceneView } from './SceneView';

type Gesture =
  | { kind: 'pan'; last: Point }
  | { kind: 'move'; ids: string[]; start: Point; startScreen: Point; started: boolean }
  | { kind: 'resize'; id: string; handle: HandleId; ratio: boolean }
  | { kind: 'rotate'; id: string };

const HANDLES: HandleId[] = ['nw', 'ne', 'se', 'sw'];
const MOVE_THRESHOLD = 3;

export function Viewport() {
  const ref = useRef<HTMLDivElement>(null);
  const pointers = useRef(new Map<number, Point>());
  const gesture = useRef<Gesture | null>(null);
  const pinch = useRef<{ dist: number; center: Point } | null>(null);
  const lastTap = useRef<{ id: string; t: number; x: number; y: number } | null>(null);
  /** Edit mode starts on pointer-up: mounting a textarea mid-press would lose focus to the browser's own mousedown handling. */
  const pendingEdit = useRef<string | null>(null);

  const doc = useEditor((s) => s.history.present);
  const camera = useEditor((s) => s.camera);
  const viewport = useEditor((s) => s.viewport);
  const mode = useEditor((s) => s.mode);
  const slideId = useEditor((s) => s.slideId);
  const selection = useEditor((s) => s.selection);
  const editingId = useEditor((s) => s.editingId);
  const tool = useEditor((s) => s.tool);

  const space = mode === 'slide' ? slideId : null;
  const slide = mode === 'slide' ? doc.slides.find((x) => x.id === slideId) : undefined;
  const objectCount = objectsInSpace(doc, space).length;

  // measure
  useEffect(() => {
    const el = ref.current!;
    const ro = new ResizeObserver(() => setViewport({ width: el.clientWidth, height: el.clientHeight }));
    ro.observe(el);
    setViewport({ width: el.clientWidth, height: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  // wheel zoom (non-passive so we can preventDefault)
  useEffect(() => {
    const el = ref.current!;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      const k = e.ctrlKey ? 0.01 : 0.0016;
      zoomBy(Math.exp(-e.deltaY * k * (e.deltaMode === 1 ? 16 : 1)), { x: e.clientX - r.left, y: e.clientY - r.top });
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  const local = (e: { clientX: number; clientY: number }): Point => {
    const r = ref.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  const toWorld = (p: Point) => {
    const s = useEditor.getState();
    return screenToWorld(s.camera, s.viewport, p);
  };

  function abort() {
    if (gesture.current && gesture.current.kind !== 'pan') cancelGesture();
    gesture.current = null;
  }

  function onPointerDown(e: React.PointerEvent) {
    const target = e.target as HTMLElement;
    if (target.closest('.zoom-controls, .inline-editor, .frame-label.editing')) return;
    try { ref.current!.setPointerCapture(e.pointerId); } catch { /* pointer already gone */ }
    const p = local(e);
    pointers.current.set(e.pointerId, p);
    const s = useEditor.getState();

    if (pointers.current.size === 2) {
      abort();
      const [a, b] = [...pointers.current.values()];
      pinch.current = { dist: Math.hypot(a!.x - b!.x, a!.y - b!.y), center: { x: (a!.x + b!.x) / 2, y: (a!.y + b!.y) / 2 } };
      return;
    }
    if (pointers.current.size > 2) return;

    if (e.button === 1 || s.tool === 'hand' || s.space) { gesture.current = { kind: 'pan', last: p }; return; }
    if (e.button !== 0 && e.pointerType === 'mouse') return;

    const handleEl = target.closest<HTMLElement>('[data-handle]');
    if (handleEl && s.selection.length === 1) {
      const id = s.selection[0]!;
      const h = handleEl.dataset.handle!;
      beginGesture();
      const o = s.history.present.objects[id]!;
      gesture.current = h === 'rotate'
        ? { kind: 'rotate', id }
        : { kind: 'resize', id, handle: h as HandleId, ratio: o.type === 'circle' || o.type === 'image' };
      return;
    }

    const objEl = target.closest<HTMLElement>('[data-id]');
    if (objEl) {
      const id = objEl.dataset.id!;
      if (e.shiftKey) {
        select(s.selection.includes(id) ? s.selection.filter((x) => x !== id) : [...s.selection, id]);
        return;
      }
      // Double-click / double-tap: handled here because pointer capture retargets native dblclick to the stage.
      const prev = lastTap.current;
      const now = performance.now();
      const o = s.history.present.objects[id];
      if (prev && prev.id === id && now - prev.t < 400 && Math.hypot(p.x - prev.x, p.y - prev.y) < 12 && o && (o.type === 'text' || o.type === 'card' || o.type === 'frame')) {
        lastTap.current = null;
        select([id]);
        pendingEdit.current = id;
        return;
      }
      lastTap.current = { id, t: now, x: p.x, y: p.y };
      const sel = s.selection.includes(id) ? s.selection : [id];
      if (sel !== s.selection) select(sel);
      gesture.current = { kind: 'move', ids: topLevel(s.history.present, sel), start: toWorld(p), startScreen: p, started: false };
      return;
    }

    // empty space: touch/pen drags pan; a mouse click just clears the selection
    if (e.pointerType !== 'mouse') gesture.current = { kind: 'pan', last: p };
    if (!e.shiftKey) select([]);
  }

  function onPointerMove(e: React.PointerEvent) {
    const p = local(e);
    if (pointers.current.has(e.pointerId)) pointers.current.set(e.pointerId, p);

    if (pinch.current && pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      const dist = Math.hypot(a!.x - b!.x, a!.y - b!.y);
      const center = { x: (a!.x + b!.x) / 2, y: (a!.y + b!.y) / 2 };
      if (pinch.current.dist > 0) zoomBy(dist / pinch.current.dist, center);
      panScreen(center.x - pinch.current.center.x, center.y - pinch.current.center.y);
      pinch.current = { dist, center };
      return;
    }

    const g = gesture.current;
    if (!g) return;
    if (g.kind === 'pan') {
      panScreen(p.x - g.last.x, p.y - g.last.y);
      g.last = p;
      return;
    }
    const w = toWorld(p);
    if (g.kind === 'move') {
      if (!g.started) {
        if (Math.hypot(p.x - g.startScreen.x, p.y - g.startScreen.y) < MOVE_THRESHOLD) return;
        g.started = true;
        beginGesture();
      }
      const dx = w.x - g.start.x;
      const dy = w.y - g.start.y;
      liveUpdate((base) => moveObjects(base, g.ids, dx, dy));
    } else if (g.kind === 'resize') {
      liveUpdate((base) => {
        const o = base.objects[g.id];
        if (!o) return base;
        const r = resizeBox(o, g.handle, w, { keepRatio: g.ratio || e.shiftKey });
        return updateObject(base, g.id, { x: r.x, y: r.y, w: r.w, h: r.h });
      });
    } else if (g.kind === 'rotate') {
      liveUpdate((base) => {
        const o = base.objects[g.id];
        if (!o) return base;
        return updateObject(base, g.id, { rotation: Math.round(rotationToward(o, w, e.shiftKey) * 10) / 10 });
      });
    }
  }

  function onPointerUp(e: React.PointerEvent) {
    pointers.current.delete(e.pointerId);
    if (pendingEdit.current) {
      const id = pendingEdit.current;
      pendingEdit.current = null;
      if (getDoc().objects[id]) useEditor.setState({ editingId: id });
      return;
    }
    if (pinch.current) { if (pointers.current.size < 2) pinch.current = null; gesture.current = null; return; }
    const g = gesture.current;
    gesture.current = null;
    if (!g || g.kind === 'pan') return;
    if (g.kind === 'move' && !g.started) return;
    // settle containment, then record ONE undo step for the whole gesture
    if (useEditor.getState().mode === 'canvas') {
      if (g.kind === 'move') liveAdjust((d) => g.ids.reduce((acc, id) => autoParent(acc, id), d));
      if (g.kind === 'resize' && getDoc().objects[g.id]?.type === 'frame') liveAdjust(reparentAll);
    }
    endGesture();
  }

  const sel = selection.map((id) => doc.objects[id]).filter((o): o is SceneObject => !!o && o.slideId === space);
  const single = sel.length === 1 ? sel[0]! : null;
  const inv = 1 / camera.zoom;
  const cursor = tool === 'hand' ? 'grab' : 'default';

  return (
    <div
      ref={ref}
      className={`stage-wrap ${mode === 'slide' ? 'slide-mode' : ''}`}
      style={{ cursor }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={(e) => { pointers.current.delete(e.pointerId); pinch.current = null; abort(); }}
      data-testid="stage"
    >
      <div
        className="world"
        data-testid="world"
        style={{ transform: cameraToCss(camera, viewport), ['--inv' as string]: inv }}
      >
        {slide ? <div className="paper" style={{ width: slide.width, height: slide.height }} /> : null}
        <SceneView doc={doc} slideId={space} editingId={editingId} onCommitText={commitText} />
        {sel.map((o) => (
          <div key={`sel-${o.id}`} className="sel-outline" style={{ left: o.x, top: o.y, width: o.w, height: o.h, transform: o.rotation ? `rotate(${o.rotation}deg)` : undefined }} />
        ))}
        {single && !editingId ? (
          <>
            {HANDLES.map((h) => {
              const p = handleWorldPosition(single, h);
              return <div key={h} className={`handle handle-${h}`} data-handle={h} style={{ left: p.x, top: p.y }} />;
            })}
            {(() => {
              const p = handleWorldPosition(single, 'rotate', 30 * inv);
              const a = handleWorldPosition(single, 'rotate', 0);
              return (
                <>
                  <div className="rotate-stem" style={{ left: a.x, top: a.y, height: 30 * inv, transform: `translate(-50%,-100%) rotate(${single.rotation}deg)`, transformOrigin: '50% 100%' }} />
                  <div className="handle handle-rotate" data-handle="rotate" style={{ left: p.x, top: p.y }} />
                </>
              );
            })()}
          </>
        ) : null}
      </div>

      {objectCount === 0 ? (
        <div className="empty-note">{mode === 'slide' ? 'This slide is empty' : 'Your ideas start here'}<br /><small>Use the toolbar to add content</small></div>
      ) : null}
      <div className="selection-hint">Drag to move · Double-click text to edit · Space + drag to pan · Scroll to zoom</div>
      <div className="zoom-controls">
        <button aria-label="Zoom out" onClick={() => zoomBy(1 / 1.2)}>−</button>
        <span data-testid="zoom-label">{Math.round(camera.zoom * 100)}%</span>
        <button aria-label="Zoom in" onClick={() => zoomBy(1.2)}>＋</button>
        <button aria-label="Fit view" onClick={() => fitView(true)}>⤢</button>
      </div>
    </div>
  );
}

export { setCamera };
