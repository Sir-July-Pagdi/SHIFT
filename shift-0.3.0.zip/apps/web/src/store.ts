import { create } from 'zustand';
import {
  createDocument, createFromTemplate, uid, validateDocument,
  type ObjectType, type SceneObject, type ShiftDocument,
} from '@shift/document-model';
import {
  addObject, addSlide, autoParent, boundsOf, cameraAt, cameraForRect, canRedo, canUndo, commit, commitTransient,
  createHistory, createPath, deletePath, duplicateObjects, duplicateSlide, frameToSlide, getActivePath, makeObject,
  moveObjects, moveSlide, moveStep, objectsInSpace, redo as redoH, undo as undoH, removeObjects, removeSlide, removeStep,
  reorderZ, replacePresent, reparentAll, resolveSteps, setActivePath, slideShowSteps, slideToFrame, stepZ, updateObject,
  updateSlide, updateStep, zoomAt, panBy, topLevel, renamePath, withDescendants,
  type CameraState, type History, type Point, type ResolvedStep, type Viewport,
} from '@shift/engine';
import { measureImage, seedAssetUrl } from './assets';
import { putAsset, setSetting, type StorageStatus } from './storage/db';

export type Mode = 'canvas' | 'slide';
export type Modal = null | 'templates' | 'documents';
export type SaveStatus = 'saved' | 'saving' | 'error';

export interface PresentSession { doc: ShiftDocument; steps: ResolvedStep[]; index: number }

export interface EditorState {
  history: History<ShiftDocument>;
  base: ShiftDocument | null;
  selection: string[];
  mode: Mode;
  slideId: string | null;
  camera: CameraState;
  cameras: Partial<Record<Mode, CameraState>>;
  viewport: Viewport;
  needsFit: boolean;
  tool: 'select' | 'hand';
  space: boolean;
  editingId: string | null;
  stepId: string | null;
  saveStatus: SaveStatus;
  storage: StorageStatus | null;
  toast: { id: number; msg: string } | null;
  modal: Modal;
  drawer: boolean;
  panel: null | 'left' | 'right';
  ribbon: string;
  present: PresentSession | null;
  reducedMotion: boolean;
  recovery: ShiftDocument | null;
}

/** Unknown until the stage is measured; fitting is deferred until then (see setViewport). */
const EMPTY_VP: Viewport = { width: 0, height: 0 };
const initialDoc = createDocument();

export const useEditor = create<EditorState>(() => ({
  history: createHistory(initialDoc),
  base: null,
  selection: [],
  mode: 'canvas',
  slideId: null,
  camera: { x: 480, y: 300, zoom: 1, rotation: 0 },
  cameras: {},
  viewport: EMPTY_VP,
  needsFit: true,
  tool: 'select',
  space: false,
  editingId: null,
  stepId: null,
  saveStatus: 'saved',
  storage: null,
  toast: null,
  modal: null,
  drawer: false,
  panel: null,
  ribbon: 'Home',
  present: null,
  reducedMotion: false,
  recovery: null,
}));

const S = () => useEditor.getState();
const set = useEditor.setState;
export const getDoc = () => S().history.present;

export const prefersReducedMotion = () =>
  S().reducedMotion || (typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches);

let toastSeq = 0;
export function toast(msg: string) {
  const id = ++toastSeq;
  set({ toast: { id, msg } });
  setTimeout(() => { if (S().toast?.id === id) set({ toast: null }); }, 2200);
}

// ---------------------------------------------------------------- history ---

export function apply(fn: (d: ShiftDocument) => ShiftDocument, selection?: string[]) {
  const s = S();
  const next = fn(s.history.present);
  if (next === s.history.present && !selection) return;
  set({ history: commit(s.history, next), ...(selection ? { selection } : {}) });
  pruneSelection();
}

let lastCoalesce: { key: string; at: number } | null = null;
/** Like apply, but rapid repeated edits with the same key (typing, colour dragging) share one undo step. */
export function applyCoalesced(key: string, fn: (d: ShiftDocument) => ShiftDocument) {
  const s = S();
  const next = fn(s.history.present);
  if (next === s.history.present) return;
  const now = Date.now();
  if (lastCoalesce && lastCoalesce.key === key && now - lastCoalesce.at < 800 && s.history.past.length) {
    set({ history: replacePresent(s.history, next) });
  } else {
    set({ history: commit(s.history, next) });
  }
  lastCoalesce = { key, at: now };
}

export function beginGesture() {
  const s = S();
  if (!s.base) set({ base: s.history.present });
}
export function liveUpdate(fn: (base: ShiftDocument) => ShiftDocument) {
  const s = S();
  const base = s.base ?? s.history.present;
  set({ history: replacePresent(s.history, fn(base)), base });
}
/** Adjust the live state at the end of a gesture (e.g. settle containment) without touching the recorded base. */
export function liveAdjust(fn: (current: ShiftDocument) => ShiftDocument) {
  const s = S();
  set({ history: replacePresent(s.history, fn(s.history.present)) });
}
export function endGesture() {
  const s = S();
  if (!s.base) return;
  set({ history: commitTransient(s.history, s.base), base: null });
}
export function cancelGesture() {
  const s = S();
  if (!s.base) return;
  set({ history: replacePresent(s.history, s.base), base: null });
}

function pruneSelection() {
  const s = S();
  const doc = s.history.present;
  const keep = s.selection.filter((id) => doc.objects[id]);
  const slideOk = s.slideId === null || doc.slides.some((x) => x.id === s.slideId);
  const patch: Partial<EditorState> = {};
  if (keep.length !== s.selection.length) patch.selection = keep;
  if (s.editingId && !doc.objects[s.editingId]) patch.editingId = null;
  if (s.mode === 'slide' && !slideOk) patch.slideId = doc.slides[0]?.id ?? null;
  if (Object.keys(patch).length) set(patch);
}

export function undo() {
  const s = S();
  if (!canUndo(s.history)) return;
  set({ history: undoH(s.history), base: null, editingId: null });
  pruneSelection();
  lastCoalesce = null;
}
export function redo() {
  const s = S();
  if (!canRedo(s.history)) return;
  set({ history: redoH(s.history), base: null, editingId: null });
  pruneSelection();
  lastCoalesce = null;
}

// ----------------------------------------------------------------- camera ---

let anim = 0;
/** Any direct camera change must cancel an in-flight fly-to, or the animation overwrites it. */
const stopAnim = () => cancelAnimationFrame(anim);
export function setCamera(camera: CameraState) { stopAnim(); set({ camera }); }

export function animateCamera(to: CameraState, ms = 450) {
  cancelAnimationFrame(anim);
  const from = S().camera;
  if (prefersReducedMotion() || ms <= 0) { set({ camera: to }); return; }
  const t0 = performance.now();
  const tick = (now: number) => {
    set({ camera: cameraAt(from, to, now - t0, ms, 'easeInOut') });
    if (now - t0 < ms) anim = requestAnimationFrame(tick);
  };
  anim = requestAnimationFrame(tick);
}

export function fitCamera(): CameraState {
  const { history, mode, slideId, viewport } = S();
  const doc = history.present;
  if (mode === 'slide') {
    const slide = doc.slides.find((x) => x.id === slideId) ?? doc.slides[0];
    return slide ? cameraForRect({ x: 0, y: 0, w: slide.width, h: slide.height }, viewport, { padding: 28, maxZoom: 3 }) : S().camera;
  }
  const rects = objectsInSpace(doc, null).map((o) => ({ x: o.x, y: o.y, w: o.w, h: o.h }));
  const b = boundsOf(rects);
  return b ? cameraForRect(b, viewport, { padding: 60, maxZoom: 1.4 }) : { x: 480, y: 300, zoom: 1, rotation: 0 };
}
export function fitView(animated = false) {
  const cam = fitCamera();
  if (animated) animateCamera(cam); else { stopAnim(); set({ camera: cam }); }
}

export function setViewport(viewport: Viewport) {
  set({ viewport });
  if (S().needsFit && viewport.width > 50) { set({ needsFit: false }); fitView(); }
}

export function zoomBy(factor: number, at?: Point) {
  stopAnim();
  const { camera, viewport } = S();
  set({ camera: zoomAt(camera, viewport, at ?? { x: viewport.width / 2, y: viewport.height / 2 }, factor) });
}
export function panScreen(dx: number, dy: number) { stopAnim(); set({ camera: panBy(S().camera, dx, dy) }); }

/** World point at the visual centre of the editor viewport (or the slide centre in slide mode). */
export function viewCenter(): Point {
  const { mode, slideId, camera, history } = S();
  if (mode === 'slide') {
    const sl = history.present.slides.find((x) => x.id === slideId);
    return sl ? { x: sl.width / 2, y: sl.height / 2 } : { x: 480, y: 270 };
  }
  return { x: camera.x, y: camera.y };
}

// --------------------------------------------------------------- document ---

export function openDocument(doc: ShiftDocument, opts: { mode?: Mode } = {}) {
  const mode = opts.mode ?? 'canvas';
  set({
    history: createHistory(doc), base: null, selection: [], editingId: null, stepId: null, mode,
    slideId: mode === 'slide' ? doc.slides[0]?.id ?? null : null, cameras: {}, needsFit: true, present: null,
    saveStatus: 'saved', modal: null, drawer: false,
  });
  if (S().viewport.width > 50) { set({ needsFit: false }); fitView(); }
  void setSetting('lastDocId', doc.id);
}

export function newDocument() { openDocument(createFromTemplate('blank').doc); toast('New presentation'); }

export function starterDocument(): ShiftDocument {
  let d = createDocument('Untitled presentation');
  const title = makeObject('text', { x: 0, y: 0 }, null, { text: 'Ideas in Motion.', fontSize: 54, w: 600, h: 90 });
  title.x = 80; title.y = 65;
  const card = makeObject('card', { x: 0, y: 0 }, null, { text: 'Start with the big picture.\nZoom into the details.', fontSize: 25, w: 340, h: 180 });
  card.x = 100; card.y = 190;
  const dot = makeObject('circle', { x: 0, y: 0 }, null, { fill: '#4387e9', w: 155, h: 155 });
  dot.x = 540; dot.y = 225;
  const frame = makeObject('frame', { x: 0, y: 0 }, null, { text: '01 · The Big Idea', w: 700, h: 470 });
  frame.x = 55; frame.y = 35;
  d = addObject(d, frame);
  for (const o of [title, card, dot]) { d = addObject(d, o); d = autoParent(d, o.id); }
  return d;
}

/** Replace the current document's content with a template (undoable). Keeps id and creation date. */
export function applyTemplate(id: string) {
  const { doc, mode } = createFromTemplate(id);
  const cur = getDoc();
  apply(() => ({ ...doc, id: cur.id, createdAt: cur.createdAt, assets: {}, updatedAt: Date.now() }), []);
  set({ mode, slideId: mode === 'slide' ? getDoc().slides[0]?.id ?? null : null, modal: null, stepId: null, editingId: null });
  fitView();
  toast('Template loaded — edit every element');
}

export function setTitle(title: string) { applyCoalesced('title', (d) => ({ ...d, title, updatedAt: Date.now() })); }

export function setMode(mode: Mode) {
  const s = S();
  if (s.mode === mode) return;
  const cameras = { ...s.cameras, [s.mode]: s.camera };
  let slideId = s.slideId;
  if (mode === 'slide') {
    if (!s.history.present.slides.length) {
      const r = addSlide(s.history.present);
      set({ history: commit(s.history, r.doc) });
      slideId = r.slideId;
    } else if (!slideId || !s.history.present.slides.some((x) => x.id === slideId)) slideId = s.history.present.slides[0]!.id;
  }
  set({ mode, slideId: mode === 'slide' ? slideId : null, selection: [], editingId: null, cameras });
  const saved = cameras[mode];
  stopAnim();
  if (saved) set({ camera: saved }); else fitView();
}

export function selectSlide(id: string) {
  set({ slideId: id, selection: [], editingId: null, mode: 'slide' });
  fitView();
}

// ---------------------------------------------------------------- objects ---

export const currentSlideId = () => (S().mode === 'slide' ? S().slideId : null);

export function addOfType(type: Exclude<ObjectType, 'image'>) {
  const s = S();
  const slideId = currentSlideId();
  if (type === 'frame' && slideId !== null) { toast('Frames live on the canvas — switch to Canvas mode'); return; }
  const o = makeObject(type, viewCenter(), slideId);
  apply((d) => {
    let next = addObject(d, o);
    if (slideId === null) next = autoParent(next, o.id);
    return next;
  }, [o.id]);
  if (type === 'text') set({ editingId: o.id });
  if (s.panel) set({ panel: null });
}

export async function addImageFile(file: File) {
  if (!file.type.startsWith('image/')) { toast('That file is not an image'); return; }
  const doc = getDoc();
  const assetId = uid();
  try {
    await putAsset({ id: assetId, docId: doc.id, name: file.name, mime: file.type, blob: file });
  } catch {
    toast('Could not store the image — storage may be full');
    return;
  }
  seedAssetUrl(assetId, file);
  const { w, h } = await measureImage(file);
  const scale = Math.min(1, 420 / w, 320 / h);
  const slideId = currentSlideId();
  const o = makeObject('image', viewCenter(), slideId, { assetId, w: Math.round(w * scale), h: Math.round(h * scale) });
  apply((d) => {
    let next = addObject({ ...d, assets: { ...d.assets, [assetId]: { id: assetId, name: file.name, mime: file.type, size: file.size } } }, o);
    if (slideId === null) next = autoParent(next, o.id);
    return next;
  }, [o.id]);
}

export function select(ids: string[]) { set({ selection: ids, editingId: null }); }
export function patchSelected(patch: Partial<SceneObject>, coalesceKey?: string) {
  const ids = S().selection;
  if (!ids.length) return;
  const fn = (d: ShiftDocument) => ids.reduce((acc, id) => updateObject(acc, id, patch), d);
  if (coalesceKey) applyCoalesced(`${coalesceKey}:${ids.join(',')}`, fn); else apply(fn);
}
export function patchObject(id: string, patch: Partial<SceneObject>, coalesceKey?: string) {
  const fn = (d: ShiftDocument) => updateObject(d, id, patch);
  if (coalesceKey) applyCoalesced(`${coalesceKey}:${id}`, fn); else apply(fn);
}
export function commitText(id: string, text: string) {
  set({ editingId: null });
  const o = getDoc().objects[id];
  if (o && o.text !== text) apply((d) => updateObject(d, id, { text }));
}

export function deleteSelected() {
  const ids = S().selection;
  if (!ids.length) return;
  apply((d) => removeObjects(d, ids), []);
}
export function duplicateSelected() {
  const ids = S().selection;
  if (!ids.length) return;
  const r = duplicateObjects(getDoc(), ids);
  apply(() => r.doc, r.ids);
}
export function nudgeSelected(dx: number, dy: number) {
  const ids = topLevel(getDoc(), S().selection);
  if (!ids.length) return;
  applyCoalesced(`nudge:${ids.join(',')}`, (d) => moveObjects(d, ids, dx, dy));
}
export function arrange(kind: 'forward' | 'backward' | 'front' | 'back') {
  const ids = S().selection;
  if (!ids.length) return;
  apply((d) => ids.reduce((acc, id) => (kind === 'forward' ? stepZ(acc, id, 1) : kind === 'backward' ? stepZ(acc, id, -1) : reorderZ(acc, id, kind)), d));
}
export function selectAll() {
  const { mode, slideId } = S();
  set({ selection: objectsInSpace(getDoc(), mode === 'slide' ? slideId : null).map((o) => o.id) });
}
export const finishFrameResize = (d: ShiftDocument) => reparentAll(d);

// ------------------------------------------------------------ path / slides ---

export function addFrameAtView() { addOfType('frame'); }

export function flyToStep(stepId: string) {
  const doc = getDoc();
  const path = getActivePath(doc);
  const r = path && resolveSteps(doc, path.steps).find((x) => x.step.id === stepId);
  set({ stepId });
  if (!r) return;
  if (r.space.kind === 'slide') { selectSlide(r.space.slideId); return; }
  if (S().mode !== 'canvas') setMode('canvas');
  animateCamera(cameraForRect(r.rect, S().viewport, { padding: 60, maxZoom: 1.6 }));
}
export const pathMove = (from: number, to: number) => apply((d) => moveStep(d, from, to));
export const pathRemove = (stepId: string) => apply((d) => removeStep(d, stepId));
export const pathStepUpdate = (stepId: string, patch: Parameters<typeof updateStep>[2]) => applyCoalesced(`step:${stepId}`, (d) => updateStep(d, stepId, patch));
export const pathNew = () => apply((d) => createPath(d, `Path ${d.paths.length + 1}`));
export const pathSetActive = (id: string) => apply((d) => setActivePath(d, id));
export const pathRename = (id: string, name: string) => applyCoalesced(`pathname:${id}`, (d) => renamePath(d, id, name));
export const pathDelete = (id: string) => apply((d) => deletePath(d, id));

export function addSlideAction() {
  const r = addSlide(getDoc());
  apply(() => r.doc);
  set({ slideId: r.slideId, selection: [], mode: 'slide' });
  fitView();
}
export function duplicateSlideAction(id: string) {
  const r = duplicateSlide(getDoc(), id);
  if (!r) return;
  apply(() => r.doc);
  set({ slideId: r.slideId, selection: [] });
}
export function removeSlideAction(id: string) {
  const d = getDoc();
  if (d.slides.length <= 1 && S().mode === 'slide') { toast('A deck needs at least one slide'); return; }
  const idx = d.slides.findIndex((x) => x.id === id);
  apply((x) => removeSlide(x, id), []);
  const nd = getDoc();
  if (S().slideId === id) { set({ slideId: nd.slides[Math.min(idx, nd.slides.length - 1)]?.id ?? null }); fitView(); }
}
export const slideMove = (from: number, to: number) => apply((d) => moveSlide(d, from, to));
export const slideUpdate = (id: string, patch: Parameters<typeof updateSlide>[2], key?: string) =>
  key ? applyCoalesced(`${key}:${id}`, (d) => updateSlide(d, id, patch)) : apply((d) => updateSlide(d, id, patch));

export function convertFrameToSlide(frameId: string) {
  const r = frameToSlide(getDoc(), frameId);
  if (!r) return;
  apply(() => r.doc);
  toast(`Slide “${r.doc.slides.find((x) => x.id === r.slideId)!.name}” created from frame`);
}
export function convertSlideToFrame(slideId: string) {
  const doc = getDoc();
  const b = boundsOf(objectsInSpace(doc, null).map((o) => ({ x: o.x, y: o.y, w: o.w, h: o.h })));
  const r = slideToFrame(doc, slideId, { x: b ? b.x + b.w + 120 : 0, y: b ? b.y : 0 });
  if (!r) return;
  apply(() => r.doc);
  toast('Slide placed on the canvas as a frame (added to the path)');
}

// ------------------------------------------------------------- presenting ---

export function startPresentation(fromStepId?: string) {
  const s = S();
  const doc = s.history.present;
  let steps: ResolvedStep[];
  if (s.mode === 'slide') steps = resolveSteps(doc, slideShowSteps(doc));
  else steps = resolveSteps(doc, getActivePath(doc)?.steps ?? []);
  if (!steps.length && s.mode === 'canvas') {
    const b = boundsOf(objectsInSpace(doc, null).map((o) => ({ x: o.x, y: o.y, w: o.w, h: o.h })));
    if (b) steps = [{ step: { id: 'overview', target: { kind: 'frame', frameId: '' }, duration: 0, easing: 'linear' }, space: { kind: 'canvas' }, rect: b, label: 'Overview' }];
  }
  if (!steps.length) { toast(s.mode === 'canvas' ? 'Add a frame or some content first' : 'Add a slide first'); return; }
  let index = 0;
  if (s.mode === 'slide' && s.slideId) index = Math.max(0, steps.findIndex((r) => r.space.kind === 'slide' && r.space.slideId === s.slideId));
  if (fromStepId) index = Math.max(0, steps.findIndex((r) => r.step.id === fromStepId));
  set({ present: { doc, steps, index }, selection: [], editingId: null, drawer: false, panel: null });
}
export function stopPresentation() { set({ present: null }); }

// ------------------------------------------------------------------ misc ---

export function setReducedMotion(v: boolean) { set({ reducedMotion: v }); void setSetting('reducedMotion', v); }
export const validateCurrent = () => validateDocument(getDoc());
export { withDescendants };
