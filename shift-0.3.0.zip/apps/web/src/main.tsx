import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import { App } from './App';
import { boot } from './boot';
import { useEditor } from './store';
import './styles.css';

registerSW({ immediate: true });

// Test/debug hook: open with ?debug to inspect the editor store from the console or e2e tests.
if (new URLSearchParams(location.search).has('debug')) (window as unknown as { __shift: unknown }).__shift = useEditor;

const root = createRoot(document.getElementById('root')!);
boot().then(() => root.render(<StrictMode><App /></StrictMode>)).catch((e) => {
  console.error('boot failed', e);
  document.getElementById('root')!.textContent = 'Shift could not start: ' + String(e);
});
