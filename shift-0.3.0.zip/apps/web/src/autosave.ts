import { saveDocument, saveSnapshot, storageStatus } from './storage/db';
import { toast, useEditor } from './store';

const DEBOUNCE_MS = 400;
const SNAPSHOT_EVERY_MS = 20_000;

let timer: ReturnType<typeof setTimeout> | undefined;
let queue: Promise<void> = Promise.resolve();
let lastSnapshotAt = 0;
let started = false;

/** Writes are serialised so an older save can never land after a newer one. */
export function flushSave(): Promise<void> {
  clearTimeout(timer);
  queue = queue.then(async () => {
    const doc = useEditor.getState().history.present;
    try {
      await saveDocument(doc);
      if (Date.now() - lastSnapshotAt > SNAPSHOT_EVERY_MS) { lastSnapshotAt = Date.now(); await saveSnapshot(doc); }
      if (useEditor.getState().history.present === doc) useEditor.setState({ saveStatus: 'saved' });
      void storageStatus().then((storage) => { useEditor.setState({ storage }); });
    } catch (e) {
      useEditor.setState({ saveStatus: 'error' });
      toast('Could not save locally — export a backup now');
      console.error('autosave failed', e);
    }
  });
  return queue;
}

export function startAutosave() {
  if (started) return;
  started = true;
  let prev = useEditor.getState().history.present;
  useEditor.subscribe((s) => {
    const d = s.history.present;
    if (d === prev) return;
    prev = d;
    if (s.saveStatus !== 'saving') useEditor.setState({ saveStatus: 'saving' });
    clearTimeout(timer);
    timer = setTimeout(() => { void flushSave(); }, DEBOUNCE_MS);
  });
  // Best-effort flush when the page is hidden or closed.
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') void flushSave(); });
  window.addEventListener('pagehide', () => { void flushSave(); });
  // Never silently lose unsaved work.
  window.addEventListener('beforeunload', (e) => {
    if (useEditor.getState().saveStatus !== 'saved') { e.preventDefault(); e.returnValue = ''; }
  });
}
