import { useEffect, useRef, useState } from 'react';
import { TEMPLATES } from '@shift/document-model';
import { createNewDocument, importFile, openDocumentById, removeDocument } from '../fileActions';
import { listDocuments } from '../storage/db';
import { applyTemplate, useEditor } from '../store';

function Modal({ title, onClose, children, id }: { title: string; onClose: () => void; children: React.ReactNode; id: string }) {
  return (
    <div className="modal-back" onClick={onClose} data-testid={id}>
      <div className="modal" role="dialog" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="modal-head"><h2>{title}</h2><button aria-label="Close" onClick={onClose}>✕</button></div>
        {children}
      </div>
    </div>
  );
}

export function Modals() {
  const modal = useEditor((s) => s.modal);
  const close = () => useEditor.setState({ modal: null });
  if (modal === 'templates') return <TemplatesModal onClose={close} />;
  if (modal === 'documents') return <DocumentsModal onClose={close} />;
  return null;
}

function TemplatesModal({ onClose }: { onClose: () => void }) {
  return (
    <Modal title="Choose a starting point" onClose={onClose} id="templates-modal">
      <p className="muted">Templates replace this presentation’s content (you can undo). Every object stays editable.</p>
      <div className="template-grid">
        {TEMPLATES.map((t) => (
          <button key={t.id} className="template-card" data-template={t.id} onClick={() => applyTemplate(t.id)}>
            <strong>{t.name}</strong><span>{t.description}</span><em>{t.kind === 'slides' ? 'Slides' : 'Canvas'}</em>
          </button>
        ))}
      </div>
    </Modal>
  );
}

function DocumentsModal({ onClose }: { onClose: () => void }) {
  const [rows, setRows] = useState<Awaited<ReturnType<typeof listDocuments>>>([]);
  const [confirm, setConfirm] = useState<string | null>(null);
  const current = useEditor((s) => s.history.present.id);
  const file = useRef<HTMLInputElement>(null);
  const reload = () => { void listDocuments().then(setRows); };
  useEffect(reload, []);
  return (
    <Modal title="Your presentations" onClose={onClose} id="documents-modal">
      <div className="modal-actions">
        <button onClick={() => { void createNewDocument().then(onClose); }}>＋ New presentation</button>
        <button onClick={() => file.current?.click()}>Import file…</button>
        <input ref={file} type="file" accept=".json,application/json" hidden data-testid="import-input"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) void importFile(f).then(onClose); e.target.value = ''; }} />
      </div>
      <div className="doc-list">
        {rows.map((r) => (
          <div key={r.id} className={`doc-row ${r.id === current ? 'current' : ''}`}>
            <button className="doc-open" onClick={() => { void openDocumentById(r.id).then((ok) => ok && onClose()); }}>
              <strong>{r.title || 'Untitled'}</strong><span>{new Date(r.updatedAt).toLocaleString()}{r.id === current ? ' · open' : ''}</span>
            </button>
            {confirm === r.id
              ? <button className="danger" onClick={() => { void removeDocument(r.id).then(() => { setConfirm(null); reload(); }); }}>Really delete</button>
              : <button aria-label={`Delete ${r.title}`} onClick={() => setConfirm(r.id)}>Delete</button>}
          </div>
        ))}
        {rows.length === 0 ? <div className="muted">Nothing saved yet.</div> : null}
      </div>
    </Modal>
  );
}
