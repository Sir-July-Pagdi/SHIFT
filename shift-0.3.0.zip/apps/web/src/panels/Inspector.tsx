import { useState } from 'react';
import type { SceneObject } from '@shift/document-model';
import { getActivePath } from '@shift/engine';
import {
  arrange, convertFrameToSlide, deleteSelected, duplicateSelected, patchObject, setMode, setTitle, slideUpdate, useEditor,
} from '../store';

const NUM_KEYS = ['x', 'y', 'w', 'h', 'rotation', 'fontSize'] as const;

function Num({ id, k, label, o, min }: { id: string; k: (typeof NUM_KEYS)[number]; label: string; o: SceneObject; min?: number }) {
  const v = Math.round(o[k] * 10) / 10;
  return (
    <div className="field">
      <label htmlFor={`f-${k}`}>{label}</label>
      <input
        id={`f-${k}`} data-k={k} type="number" min={min} key={`${id}:${k}:${v}`} defaultValue={v}
        onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); e.stopPropagation(); }}
        onBlur={(e) => {
          const n = Number(e.target.value);
          if (!Number.isFinite(n) || n === o[k]) { e.target.value = String(v); return; }
          patchObject(id, { [k]: min !== undefined ? Math.max(min, n) : n });
        }}
      />
    </div>
  );
}

function hex(c: string) { return /^#[0-9a-f]{6}$/i.test(c) ? c : '#ffffff'; }

export function Inspector() {
  const doc = useEditor((s) => s.history.present);
  const selection = useEditor((s) => s.selection);
  const mode = useEditor((s) => s.mode);
  const slideId = useEditor((s) => s.slideId);
  const panel = useEditor((s) => s.panel);
  const [, force] = useState(0);
  void force;

  const o = selection.length === 1 ? doc.objects[selection[0]!] : undefined;
  const slide = mode === 'slide' ? doc.slides.find((x) => x.id === slideId) : undefined;
  const inPath = o?.type === 'frame' && !!getActivePath(doc)?.steps.some((s) => s.target.kind === 'frame' && s.target.frameId === o.id);
  const textual = o && (o.type === 'text' || o.type === 'card');

  return (
    <aside className={`right ${panel === 'right' ? 'open' : ''}`} id="inspector" data-testid="inspector">
      <div className="sidehead"><span>Format &amp; properties</span></div>
      <div id="properties">
        {selection.length > 1 ? (
          <div className="prop-section">
            <div className="prop-title">Selection</div>
            <div className="muted" data-testid="multi-note">{selection.length} objects selected</div>
            <div className="prop-actions">
              <button onClick={duplicateSelected}>Duplicate</button>
              <button className="danger" onClick={deleteSelected}>Delete</button>
            </div>
          </div>
        ) : null}

        {o ? (
          <>
            <div className="prop-section">
              <div className="prop-title">Selected · {o.type}</div>
              {o.type === 'frame' ? (
                <div className="field"><label htmlFor="f-name">Name</label>
                  <input id="f-name" data-k="name" type="text" value={o.text} onKeyDown={(e) => e.stopPropagation()} onChange={(e) => patchObject(o.id, { text: e.target.value }, 'text')} />
                </div>
              ) : null}
              <Num id={o.id} k="x" label="X" o={o} />
              <Num id={o.id} k="y" label="Y" o={o} />
              <Num id={o.id} k="w" label="Width" o={o} min={20} />
              <Num id={o.id} k="h" label="Height" o={o} min={20} />
              <Num id={o.id} k="rotation" label="Rotation" o={o} />
              {o.type !== 'text' && o.type !== 'frame' && o.type !== 'image' ? (
                <div className="field"><label htmlFor="f-fill">Fill</label>
                  <input id="f-fill" data-k="fill" type="color" value={hex(o.fill)} onChange={(e) => patchObject(o.id, { fill: e.target.value }, 'fill')} /></div>
              ) : null}
              {textual ? (
                <>
                  <div className="field"><label htmlFor="f-color">Text colour</label>
                    <input id="f-color" data-k="color" type="color" value={hex(o.color)} onChange={(e) => patchObject(o.id, { color: e.target.value }, 'color')} /></div>
                  <Num id={o.id} k="fontSize" label="Font size" o={o} min={8} />
                  <div className="field"><label htmlFor="f-bold">Bold</label>
                    <input id="f-bold" data-k="bold" type="checkbox" checked={o.bold} onChange={(e) => patchObject(o.id, { bold: e.target.checked })} /></div>
                  <textarea className="text-field" aria-label="Text" data-k="text" value={o.text} onKeyDown={(e) => e.stopPropagation()} onChange={(e) => patchObject(o.id, { text: e.target.value }, 'text')} />
                </>
              ) : null}
              {o.type === 'frame' ? (
                <>
                  <div className="muted small">{inPath ? 'This frame is a step in the active path.' : 'This frame is not in the active path.'}</div>
                  <button className="full" onClick={() => convertFrameToSlide(o.id)}>Convert to slide</button>
                </>
              ) : null}
            </div>
            <div className="prop-section">
              <div className="prop-title">Arrange</div>
              <div className="prop-actions">
                <button onClick={() => arrange('forward')}>Bring forward</button>
                <button onClick={() => arrange('backward')}>Send backward</button>
                <button onClick={duplicateSelected}>Duplicate</button>
                <button className="danger" onClick={deleteSelected}>Delete</button>
              </div>
            </div>
          </>
        ) : null}

        {selection.length === 0 ? (
          <>
            <div className="prop-section">
              <div className="prop-title">Selection</div>
              <div className="muted">Select an object on the workspace to edit its properties.</div>
            </div>
            {slide ? (
              <div className="prop-section" data-testid="slide-props">
                <div className="prop-title">Slide</div>
                <div className="field"><label htmlFor="s-name">Name</label>
                  <input id="s-name" type="text" value={slide.name} onKeyDown={(e) => e.stopPropagation()} onChange={(e) => slideUpdate(slide.id, { name: e.target.value }, 'sname')} /></div>
                <div className="field"><label htmlFor="s-w">Width</label>
                  <input id="s-w" type="number" min={100} key={`w${slide.id}${slide.width}`} defaultValue={slide.width} onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); e.stopPropagation(); }}
                    onBlur={(e) => { const n = Math.round(Number(e.target.value)); if (n >= 100 && n !== slide.width) slideUpdate(slide.id, { width: n }); }} /></div>
                <div className="field"><label htmlFor="s-h">Height</label>
                  <input id="s-h" type="number" min={100} key={`h${slide.id}${slide.height}`} defaultValue={slide.height} onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); e.stopPropagation(); }}
                    onBlur={(e) => { const n = Math.round(Number(e.target.value)); if (n >= 100 && n !== slide.height) slideUpdate(slide.id, { height: n }); }} /></div>
                <div className="prop-title" style={{ marginTop: 12 }}>Speaker notes</div>
                <textarea className="text-field" aria-label="Speaker notes" data-testid="notes" placeholder="Notes for this slide (not shown to the audience)…" value={slide.notes}
                  onKeyDown={(e) => e.stopPropagation()} onChange={(e) => slideUpdate(slide.id, { notes: e.target.value }, 'notes')} />
              </div>
            ) : null}
            <div className="prop-section">
              <div className="prop-title">Document</div>
              <div className="field"><label htmlFor="d-title">Title</label>
                <input id="d-title" type="text" value={doc.title} onKeyDown={(e) => e.stopPropagation()} onChange={(e) => setTitle(e.target.value)} /></div>
              <div className="field"><span>Mode</span><span id="modeLabel" data-testid="mode-label">{mode === 'canvas' ? 'Canvas' : 'Slides'}</span></div>
              <div className="field"><span>Objects</span><span id="objectCount" data-testid="object-count">{Object.keys(doc.objects).length}</span></div>
              <div className="field"><span>Slides</span><span>{doc.slides.length}</span></div>
              <button className="full" onClick={() => setMode(mode === 'canvas' ? 'slide' : 'canvas')}>Switch to {mode === 'canvas' ? 'slide' : 'canvas'} mode</button>
            </div>
          </>
        ) : null}
      </div>
    </aside>
  );
}
