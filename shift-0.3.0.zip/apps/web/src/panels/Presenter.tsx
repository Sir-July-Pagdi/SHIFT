import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { cameraAt, cameraForStep, cameraToCss, type CameraState, type Viewport } from '@shift/engine';
import { SceneView } from '../editor/SceneView';
import { prefersReducedMotion, stopPresentation, useEditor } from '../store';

export function Presenter() {
  const session = useEditor((s) => s.present);
  return session ? <PresenterInner /> : null;
}

function PresenterInner() {
  const session = useEditor((s) => s.present)!;
  const { doc, steps } = session;
  const [index, setIndex] = useState(session.index);
  const [notes, setNotes] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const world = useRef<HTMLDivElement>(null);
  const cam = useRef<CameraState | null>(null);
  const vp = useRef<Viewport>({ width: window.innerWidth, height: window.innerHeight });
  const raf = useRef(0);
  const prevStep = useRef<number | null>(null);

  const step = steps[index]!;
  const slide = step.space.kind === 'slide' ? doc.slides.find((s) => s.id === (step.space as { slideId: string }).slideId) : undefined;

  const paint = useCallback((c: CameraState) => {
    cam.current = c;
    if (world.current) world.current.style.transform = cameraToCss(c, vp.current);
  }, []);

  const go = useCallback((n: number) => setIndex((i) => Math.max(0, Math.min(steps.length - 1, typeof n === 'number' ? n : i))), [steps.length]);

  // measure + fullscreen
  useLayoutEffect(() => {
    const el = root.current!;
    const measure = () => {
      vp.current = { width: el.clientWidth, height: el.clientHeight };
      cancelAnimationFrame(raf.current);
      paint(cameraForStep(steps[indexRef.current]!, vp.current));
    };
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    el.requestFullscreen?.().catch(() => { /* not allowed or unsupported: stay in the overlay */ });
    const onFs = () => { if (!document.fullscreenElement) stopPresentation(); };
    document.addEventListener('fullscreenchange', onFs);
    return () => {
      ro.disconnect();
      document.removeEventListener('fullscreenchange', onFs);
      cancelAnimationFrame(raf.current);
      if (document.fullscreenElement) void document.exitFullscreen().catch(() => undefined);
    };
  }, [paint, steps]);

  const indexRef = useRef(index);
  indexRef.current = index;

  // camera transition to the current step
  useLayoutEffect(() => {
    const to = cameraForStep(steps[index]!, vp.current);
    const prev = prevStep.current === null ? null : steps[prevStep.current];
    prevStep.current = index;
    const sameSpace = prev && JSON.stringify(prev.space) === JSON.stringify(step.space);
    const from = cam.current;
    cancelAnimationFrame(raf.current);
    if (!from || !sameSpace || prefersReducedMotion() || step.step.duration <= 0) { paint(to); return; }
    const t0 = performance.now();
    const tick = (now: number) => {
      paint(cameraAt(from, to, now - t0, step.step.duration, step.step.easing));
      if (now - t0 < step.step.duration) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
  }, [index, steps, step, paint]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key;
      if (k === 'Escape') { stopPresentation(); return; }
      if (k === 'ArrowRight' || k === 'ArrowDown' || k === 'PageDown' || k === ' ' || k === 'Enter') { e.preventDefault(); setIndex((i) => Math.min(steps.length - 1, i + 1)); }
      else if (k === 'ArrowLeft' || k === 'ArrowUp' || k === 'PageUp' || k === 'Backspace') { e.preventDefault(); setIndex((i) => Math.max(0, i - 1)); }
      else if (k === 'Home') setIndex(0);
      else if (k === 'End') setIndex(steps.length - 1);
      else if (k === 'n' || k === 'N') setNotes((v) => !v);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [steps.length]);

  return (
    <div className="presenter" ref={root} data-testid="presenter"
      onClick={(e) => {
        if ((e.target as HTMLElement).closest('.present-controls, .notes-panel')) return;
        const x = e.clientX / window.innerWidth;
        setIndex((i) => (x < 0.35 ? Math.max(0, i - 1) : Math.min(steps.length - 1, i + 1)));
      }}>
      <div className="world" ref={world} data-testid="present-world" style={{ transformOrigin: '0 0' }}>
        {slide ? (
          <div className="paper clip" style={{ width: slide.width, height: slide.height }}>
            <SceneView doc={doc} slideId={slide.id} hideFrames />
          </div>
        ) : (
          <SceneView doc={doc} slideId={null} hideFrames />
        )}
      </div>
      {notes && slide ? <div className="notes-panel" data-testid="present-notes">{slide.notes || 'No notes for this slide.'}</div> : null}
      <div className="present-controls">
        <button aria-label="Previous step" disabled={index === 0} onClick={() => go(index - 1)}>‹</button>
        <span data-testid="step-label">{index + 1} / {steps.length}</span>
        <span className="present-title">{step.label}</span>
        <button aria-label="Next step" disabled={index === steps.length - 1} onClick={() => go(index + 1)}>›</button>
        {slide ? <button aria-label="Toggle notes" className={notes ? 'active' : ''} onClick={() => setNotes((v) => !v)}>Notes</button> : null}
        <button aria-label="Exit presentation" onClick={stopPresentation}>✕ Exit</button>
      </div>
    </div>
  );
}
