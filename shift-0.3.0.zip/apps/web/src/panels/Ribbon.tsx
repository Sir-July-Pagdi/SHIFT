import { useRef } from 'react';
import { canRedo, canUndo, getActivePath, resolveSteps } from '@shift/engine';
import {
  addFrameAtView, addImageFile, addOfType, addSlideAction, arrange, convertFrameToSlide, convertSlideToFrame, deleteSelected,
  duplicateSelected, fitView, pathStepUpdate, redo, setMode, setReducedMotion, startPresentation, undo, useEditor, zoomBy,
} from '../store';

const TABS = ['Home', 'Insert', 'Design', 'Arrange', 'Animate', 'Present', 'View'] as const;

interface Item { id: string; label: string; title?: string; onClick: () => void; disabled?: boolean; active?: boolean; danger?: boolean }

export function Ribbon() {
  const tab = useEditor((s) => s.ribbon);
  const mode = useEditor((s) => s.mode);
  const tool = useEditor((s) => s.tool);
  const selection = useEditor((s) => s.selection);
  const history = useEditor((s) => s.history);
  const slideId = useEditor((s) => s.slideId);
  const stepId = useEditor((s) => s.stepId);
  const reduced = useEditor((s) => s.reducedMotion);
  const fileRef = useRef<HTMLInputElement>(null);
  const doc = history.present;

  const hasSel = selection.length > 0;
  const oneFrame = selection.length === 1 && doc.objects[selection[0]!]?.type === 'frame';
  const canvas = mode === 'canvas';

  const open = (id: string) => useEditor.setState({ modal: id as 'templates' });
  const tool_ = (t: 'select' | 'hand') => useEditor.setState({ tool: t });

  const B = {
    select: { id: 'select', label: '↖ Select', onClick: () => tool_('select'), active: tool === 'select' },
    hand: { id: 'hand', label: '✋ Pan', onClick: () => tool_('hand'), active: tool === 'hand' },
    text: { id: 'text', label: 'T Text', onClick: () => addOfType('text') },
    card: { id: 'card', label: '▣ Card', onClick: () => addOfType('card') },
    rect: { id: 'rect', label: '□ Shape', onClick: () => addOfType('rect') },
    circle: { id: 'circle', label: '◯ Circle', onClick: () => addOfType('circle') },
    frame: canvas
      ? { id: 'frame', label: '▱ Frame', title: 'Add a topic frame (also adds a path step)', onClick: addFrameAtView }
      : { id: 'slide', label: '＋ Slide', onClick: addSlideAction },
    image: { id: 'image', label: '▧ Image', onClick: () => fileRef.current?.click() },
    duplicate: { id: 'duplicate', label: 'Duplicate', onClick: duplicateSelected, disabled: !hasSel },
    delete: { id: 'delete', label: 'Delete', onClick: deleteSelected, disabled: !hasSel, danger: true },
    undo: { id: 'undo', label: '↶ Undo', onClick: undo, disabled: !canUndo(history) },
    redo: { id: 'redo', label: '↷ Redo', onClick: redo, disabled: !canRedo(history) },
    templates: { id: 'templates', label: 'Templates…', onClick: () => open('templates') },
    canvasMode: { id: 'canvas', label: 'Canvas mode', onClick: () => setMode('canvas'), active: canvas },
    slideMode: { id: 'slides', label: 'Slide mode', onClick: () => setMode('slide'), active: !canvas },
    fit: { id: 'fit', label: 'Fit view', onClick: () => fitView(true) },
    forward: { id: 'forward', label: 'Bring forward', onClick: () => arrange('forward'), disabled: !hasSel },
    backward: { id: 'backward', label: 'Send backward', onClick: () => arrange('backward'), disabled: !hasSel },
    front: { id: 'front', label: 'To front', onClick: () => arrange('front'), disabled: !hasSel },
    back: { id: 'back', label: 'To back', onClick: () => arrange('back'), disabled: !hasSel },
    frameToSlide: { id: 'frame-to-slide', label: 'Frame → Slide', title: 'Copy the selected frame’s contents onto a new slide', onClick: () => convertFrameToSlide(selection[0]!), disabled: !oneFrame },
    slideToFrame: { id: 'slide-to-frame', label: 'Slide → Frame', title: 'Place the current slide on the canvas as a frame', onClick: () => slideId && convertSlideToFrame(slideId), disabled: canvas || !slideId },
    zoomIn: { id: 'zoomin', label: 'Zoom in', onClick: () => zoomBy(1.2) },
    zoomOut: { id: 'zoomout', label: 'Zoom out', onClick: () => zoomBy(1 / 1.2) },
    present: { id: 'present', label: '▶ Start from beginning', onClick: () => startPresentation() },
    presentFrom: { id: 'present-from', label: '▶ Start from selected step', onClick: () => startPresentation(stepId ?? undefined), disabled: !canvas || !stepId },
    reduced: { id: 'reduced', label: reduced ? '✓ Reduced motion' : 'Reduced motion', title: 'Skip camera animation', onClick: () => setReducedMotion(!reduced), active: reduced },
  } satisfies Record<string, Item>;

  const sets: Record<string, Item[]> = {
    Home: [B.select, B.hand, B.text, B.card, B.rect, B.circle, B.frame, B.image, B.duplicate, B.delete, B.undo, B.redo],
    Insert: [B.text, B.card, B.rect, B.circle, B.frame, B.image],
    Design: [B.templates, B.canvasMode, B.slideMode, B.fit],
    Arrange: [B.duplicate, B.delete, B.forward, B.backward, B.front, B.back, B.frameToSlide, B.slideToFrame],
    Animate: [],
    Present: [B.present, B.presentFrom],
    View: [B.zoomIn, B.zoomOut, B.fit, B.canvasMode, B.slideMode, B.reduced],
  };

  const path = getActivePath(doc);
  const step = path?.steps.find((s) => s.id === stepId);
  const resolved = step ? resolveSteps(doc, [step])[0] : undefined;

  return (
    <>
      <nav className="tabs" role="tablist">
        {TABS.map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} className={`tab ${tab === t ? 'active' : ''}`} onClick={() => useEditor.setState({ ribbon: t })}>{t}</button>
        ))}
      </nav>
      <div className="toolbar" data-testid="ribbon" data-tab={tab}>
        <button className="narrow-only" onClick={() => useEditor.setState((s) => ({ panel: s.panel === 'left' ? null : 'left' }))}>▤ Pages</button>
        {sets[tab]!.map((b) => (
          <button key={b.id} data-ribbon={b.id} title={b.title ?? b.label} disabled={b.disabled} className={`${b.active ? 'active' : ''} ${b.danger ? 'danger' : ''}`} onClick={b.onClick}>{b.label}</button>
        ))}
        {tab === 'Animate' ? (
          <div className="step-editor" data-testid="step-editor">
            {step && resolved ? (
              <>
                <span className="muted">Transition to “{resolved.label}”</span>
                <label>Duration (ms)
                  <input type="number" min={0} max={10000} step={100} value={step.duration}
                    onChange={(e) => pathStepUpdate(step.id, { duration: Math.max(0, Number(e.target.value) || 0) })} />
                </label>
                <label>Easing
                  <select value={step.easing} onChange={(e) => pathStepUpdate(step.id, { easing: e.target.value as typeof step.easing })}>
                    <option value="easeInOut">Ease in-out</option>
                    <option value="easeOut">Ease out</option>
                    <option value="linear">Linear</option>
                  </select>
                </label>
              </>
            ) : <span className="muted">Select a step in the path (left panel) to edit its camera transition.</span>}
            <button data-ribbon="preview" onClick={() => startPresentation(stepId ?? undefined)}>▶ Preview</button>
          </div>
        ) : null}
        <button className="narrow-only" onClick={() => useEditor.setState((s) => ({ panel: s.panel === 'right' ? null : 'right' }))}>⚙ Inspector</button>
        <input ref={fileRef} type="file" accept="image/*" hidden data-testid="image-input"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) void addImageFile(f); e.target.value = ''; }} />
      </div>
    </>
  );
}
