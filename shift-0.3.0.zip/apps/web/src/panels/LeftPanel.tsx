import { getActivePath, objectsInSpace, resolveSteps } from '@shift/engine';
import type { SceneObject, ShiftDocument } from '@shift/document-model';
import { SceneView } from '../editor/SceneView';
import {
  addFrameAtView, addSlideAction, duplicateSlideAction, flyToStep, pathDelete, pathMove, pathNew, pathRemove, pathRename,
  pathSetActive, removeSlideAction, select, selectSlide, setMode, slideMove, useEditor,
} from '../store';

function depth(doc: ShiftDocument, o: SceneObject): number {
  let d = 0;
  let p = o.parentId;
  while (p && d < 20) { d++; p = doc.objects[p]?.parentId ?? null; }
  return d;
}

function layerName(o: SceneObject) {
  const t = (o.text || '').split('\n')[0]!.trim();
  return t ? t.slice(0, 28) : o.type;
}

export function LeftPanel() {
  const doc = useEditor((s) => s.history.present);
  const mode = useEditor((s) => s.mode);
  const slideId = useEditor((s) => s.slideId);
  const stepId = useEditor((s) => s.stepId);
  const selection = useEditor((s) => s.selection);
  const panel = useEditor((s) => s.panel);

  const space = mode === 'slide' ? slideId : null;
  const layers = objectsInSpace(doc, space).slice().reverse();
  const path = getActivePath(doc);
  const steps = path ? resolveSteps(doc, path.steps) : [];

  return (
    <aside className={`left ${panel === 'left' ? 'open' : ''}`} data-testid="left-panel">
      <div className="mode-switch">
        <button id="canvasMode" className={mode === 'canvas' ? 'active' : ''} onClick={() => setMode('canvas')}>Canvas</button>
        <button id="slideMode" className={mode === 'slide' ? 'active' : ''} onClick={() => setMode('slide')}>Slides</button>
      </div>

      {mode === 'canvas' ? (
        <>
          <div className="sidehead"><span>Presentation path</span><button aria-label="Add frame" title="Add frame" onClick={addFrameAtView}>＋</button></div>
          <div className="path-bar">
            <select aria-label="Active path" value={doc.activePathId ?? ''} onChange={(e) => pathSetActive(e.target.value)}>
              {doc.paths.length === 0 ? <option value="">Main path</option> : null}
              {doc.paths.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
            <button title="New path (copy of this one)" onClick={pathNew}>＋ Path</button>
            {path && doc.paths.length > 1 ? <button title="Delete this path" onClick={() => pathDelete(path.id)}>✕</button> : null}
          </div>
          {path ? (
            <input className="path-name" aria-label="Path name" value={path.name} onChange={(e) => pathRename(path.id, e.target.value)} />
          ) : null}
          <div className="sidebody" data-testid="step-list">
            {steps.length === 0 ? <div className="hint">No steps yet. Add a frame — each frame becomes a destination in the path.</div> : null}
            {steps.map((r, i) => (
              <div key={r.step.id} className={`thumb ${stepId === r.step.id ? 'selected' : ''}`} data-step={r.step.id} onClick={() => flyToStep(r.step.id)}>
                <div className="thumb-preview">
                  <Thumb doc={doc} step={r} />
                </div>
                <div className="thumb-row">
                  <span className="thumb-title">{i + 1}. {r.label}</span>
                  <span className="thumb-actions">
                    <button aria-label="Move step up" disabled={i === 0} onClick={(e) => { e.stopPropagation(); pathMove(i, i - 1); }}>↑</button>
                    <button aria-label="Move step down" disabled={i === steps.length - 1} onClick={(e) => { e.stopPropagation(); pathMove(i, i + 1); }}>↓</button>
                    <button aria-label="Remove step" onClick={(e) => { e.stopPropagation(); pathRemove(r.step.id); }}>✕</button>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <>
          <div className="sidehead"><span>Slides</span><button aria-label="Add slide" title="Add slide" onClick={addSlideAction}>＋</button></div>
          <div className="sidebody" data-testid="slide-list">
            {doc.slides.map((s, i) => (
              <div key={s.id} className={`thumb ${slideId === s.id ? 'selected' : ''}`} data-slide={s.id} onClick={() => selectSlide(s.id)}>
                <div className="thumb-preview" style={{ aspectRatio: `${s.width} / ${s.height}` }}>
                  <Thumb doc={doc} slide={s.id} />
                </div>
                <div className="thumb-row">
                  <span className="thumb-title">{s.name}</span>
                  <span className="thumb-actions">
                    <button aria-label="Move slide up" disabled={i === 0} onClick={(e) => { e.stopPropagation(); slideMove(i, i - 1); }}>↑</button>
                    <button aria-label="Move slide down" disabled={i === doc.slides.length - 1} onClick={(e) => { e.stopPropagation(); slideMove(i, i + 1); }}>↓</button>
                    <button aria-label="Duplicate slide" onClick={(e) => { e.stopPropagation(); duplicateSlideAction(s.id); }}>⧉</button>
                    <button aria-label="Delete slide" onClick={(e) => { e.stopPropagation(); removeSlideAction(s.id); }}>✕</button>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      <div className="sidehead"><span>Layers</span><span data-testid="layer-count">{layers.length}</span></div>
      <div className="sidebody layers" data-testid="layer-list">
        {layers.length === 0 ? <div className="hint">No objects yet.</div> : null}
        {layers.map((o) => (
          <div key={o.id} className={`layer ${selection.includes(o.id) ? 'selected' : ''}`} style={{ paddingLeft: 8 + depth(doc, o) * 14 }} onClick={() => select([o.id])}>
            <span className={`dot ${o.type}`} /><span className="layer-name">{layerName(o)}</span>
          </div>
        ))}
      </div>
    </aside>
  );
}

const THUMB_W = 176;

function Thumb({ doc, step, slide }: { doc: ShiftDocument; step?: ReturnType<typeof resolveSteps>[number]; slide?: string }) {
  if (slide) {
    const s = doc.slides.find((x) => x.id === slide)!;
    const k = THUMB_W / s.width;
    return (
      <div className="thumb-inner paper-bg" style={{ width: s.width, height: s.height, transform: `scale(${k})`, transformOrigin: '0 0' }}>
        <SceneView doc={doc} slideId={slide} />
      </div>
    );
  }
  const r = step!;
  if (r.space.kind === 'slide') return <div className="thumb-slide">Slide</div>;
  const k = Math.min(THUMB_W / r.rect.w, 100 / r.rect.h);
  return (
    <div className="thumb-inner dark-bg" style={{ width: r.rect.w, height: r.rect.h, transform: `scale(${k})`, transformOrigin: '0 0' }}>
      <div style={{ position: 'absolute', left: -r.rect.x, top: -r.rect.y }}>
        <SceneView doc={doc} slideId={null} hideFrames region={r.rect} />
      </div>
    </div>
  );
}
