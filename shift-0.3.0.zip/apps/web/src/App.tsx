import { useEffect } from 'react';
import { canRedo, canUndo, topLevel } from '@shift/engine';
import { Viewport } from './editor/Viewport';
import { Inspector } from './panels/Inspector';
import { LeftPanel } from './panels/LeftPanel';
import { Modals } from './panels/Modals';
import { Presenter } from './panels/Presenter';
import { Ribbon } from './panels/Ribbon';
import { acceptRecovery, createNewDocument, dismissRecovery, exportCurrent, importFile } from './fileActions';
import {
  deleteSelected, duplicateSelected, nudgeSelected, redo, select, selectAll, setMode, setTitle, startPresentation, undo, useEditor,
} from './store';
import { useRef } from 'react';

const isTyping = (t: EventTarget | null) => {
  const el = t as HTMLElement | null;
  return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable);
};

export function App() {
  const title = useEditor((s) => s.history.present.title);
  const history = useEditor((s) => s.history);
  const saveStatus = useEditor((s) => s.saveStatus);
  const storage = useEditor((s) => s.storage);
  const toast = useEditor((s) => s.toast);
  const drawer = useEditor((s) => s.drawer);
  const recovery = useEditor((s) => s.recovery);
  const mode = useEditor((s) => s.mode);
  const present = useEditor((s) => s.present);
  const panel = useEditor((s) => s.panel);
  const doc = useEditor((s) => s.history.present);
  const importRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const s = useEditor.getState();
      if (s.present) return;
      if (e.code === 'Space' && !isTyping(e.target) && !s.space) { e.preventDefault(); useEditor.setState({ space: true }); return; }
      if (isTyping(e.target)) return;
      const mod = e.ctrlKey || e.metaKey;
      const k = e.key.toLowerCase();
      if (mod && k === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); }
      else if (mod && k === 'y') { e.preventDefault(); redo(); }
      else if (mod && k === 'd') { e.preventDefault(); duplicateSelected(); }
      else if (mod && k === 'a') { e.preventDefault(); selectAll(); }
      else if (e.key === 'Delete' || e.key === 'Backspace') { if (s.selection.length) { e.preventDefault(); deleteSelected(); } }
      else if (e.key === 'Escape') { if (s.drawer) useEditor.setState({ drawer: false }); else if (s.modal) useEditor.setState({ modal: null }); else if (s.panel) useEditor.setState({ panel: null }); else select([]); }
      else if (e.key.startsWith('Arrow') && s.selection.length) {
        e.preventDefault();
        const n = e.shiftKey ? 10 : 1;
        nudgeSelected(e.key === 'ArrowLeft' ? -n : e.key === 'ArrowRight' ? n : 0, e.key === 'ArrowUp' ? -n : e.key === 'ArrowDown' ? n : 0);
      }
    };
    const up = (e: KeyboardEvent) => { if (e.code === 'Space') useEditor.setState({ space: false }); };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); };
  }, []);

  const set = useEditor.setState;
  const modeText = mode === 'canvas' ? 'Canvas workspace' : 'Slide workspace';
  const statusText = saveStatus === 'saved' ? 'Saved on this device' : saveStatus === 'saving' ? 'Saving…' : 'Save failed';

  return (
    <div className="app">
      <header className="topbar">
        <button id="menuBtn" aria-label="Menu" onClick={() => set({ drawer: !drawer })}>☰</button>
        <div className="brand">Shift</div>
        <input id="docname" aria-label="Presentation title" value={title}
          onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => e.stopPropagation()} />
        <span className={`save-status ${saveStatus}`} data-testid="save-status" data-status={saveStatus}>{statusText}</span>
        <div className="grow" />
        <button id="undoBtn" aria-label="Undo" disabled={!canUndo(history)} onClick={undo}>↶</button>
        <button id="redoBtn" aria-label="Redo" disabled={!canRedo(history)} onClick={redo}>↷</button>
        <button id="templatesBtn" onClick={() => set({ modal: 'templates' })}>Templates</button>
        <button id="presentBtn" className="primary" onClick={() => startPresentation()}>▶ Present</button>
      </header>

      {drawer ? (
        <>
          <div className="drawer-back" onClick={() => set({ drawer: false })} />
          <nav className="drawer open" id="mobileDrawer" data-testid="drawer">
            <h3>Shift</h3>
            <button data-drawer="new" onClick={() => { set({ drawer: false }); void createNewDocument(); }}>New presentation</button>
            <button data-drawer="open" onClick={() => set({ drawer: false, modal: 'documents' })}>Open…</button>
            <button data-drawer="templates" onClick={() => set({ drawer: false, modal: 'templates' })}>Templates</button>
            <button data-drawer="canvas" onClick={() => { set({ drawer: false }); setMode('canvas'); }}>Canvas mode</button>
            <button data-drawer="slides" onClick={() => { set({ drawer: false }); setMode('slide'); }}>Slide mode</button>
            <button data-drawer="export" onClick={() => { set({ drawer: false }); void exportCurrent(); }}>Export backup (.shift.json)</button>
            <button data-drawer="import" onClick={() => importRef.current?.click()}>Import file…</button>
            <p className="muted small">Shift 0.3 · offline-first · data stays on this device unless you export it.</p>
          </nav>
        </>
      ) : null}
      <input ref={importRef} type="file" accept=".json,application/json" hidden data-testid="drawer-import"
        onChange={(e) => { const f = e.target.files?.[0]; if (f) { set({ drawer: false }); void importFile(f); } e.target.value = ''; }} />

      {recovery ? (
        <div className="banner" data-testid="recovery-banner">
          A newer version of this presentation was found that did not finish saving.
          <button onClick={acceptRecovery}>Recover it</button>
          <button onClick={() => void dismissRecovery()}>Keep current</button>
        </div>
      ) : null}
      {storage?.low ? <div className="banner warn" data-testid="storage-warning">Device storage is almost full. Export a backup to keep your work safe.</div> : null}

      <Ribbon />
      <main className="main">
        <LeftPanel />
        <Viewport />
        <Inspector />
      </main>
      {panel ? <div className="panel-back" onClick={() => set({ panel: null })} /> : null}
      <footer className="bottombar">
        <span>{modeText} · {(() => { const n = topLevel(doc, Object.keys(doc.objects)).length; return `${n} ${n === 1 ? 'item' : 'items'}`; })()}</span>
        <span data-testid="storage-note">{storage ? (storage.persisted ? 'Storage: persistent' : 'Storage: browser may clear it — export backups') : ''}</span>
        <span>SHIFT 0.3 · Ideas in Motion</span>
      </footer>
      <Modals />
      {toast ? <div className="toast show" role="status" data-testid="toast">{toast.msg}</div> : null}
      {present ? <Presenter /> : null}
    </div>
  );
}
