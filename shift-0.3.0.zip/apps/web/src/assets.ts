import { useEffect, useState } from 'react';
import { getAsset } from './storage/db';

/** Object URLs for stored image blobs, created once per asset and reused by editor, thumbnails and presenter. */
const urls = new Map<string, string>();
const pending = new Map<string, Promise<string | null>>();

export function seedAssetUrl(id: string, blob: Blob) {
  if (!urls.has(id)) urls.set(id, URL.createObjectURL(blob));
}

export function ensureAssetUrl(id: string): Promise<string | null> {
  const hit = urls.get(id);
  if (hit) return Promise.resolve(hit);
  let p = pending.get(id);
  if (!p) {
    p = getAsset(id).then((a) => {
      pending.delete(id);
      if (!a) return null;
      const u = URL.createObjectURL(a.blob);
      urls.set(id, u);
      return u;
    });
    pending.set(id, p);
  }
  return p;
}

export function useAssetUrl(id: string | undefined): string | null {
  const [url, setUrl] = useState<string | null>(id ? urls.get(id) ?? null : null);
  useEffect(() => {
    let live = true;
    if (!id) { setUrl(null); return; }
    const hit = urls.get(id);
    if (hit) { setUrl(hit); return; }
    ensureAssetUrl(id).then((u) => { if (live) setUrl(u); });
    return () => { live = false; };
  }, [id]);
  return url;
}

/** Natural size of an image blob, used to give a new image object the right aspect ratio. */
export function measureImage(blob: Blob): Promise<{ w: number; h: number }> {
  return new Promise((resolve) => {
    const u = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => { resolve({ w: img.naturalWidth || 300, h: img.naturalHeight || 200 }); URL.revokeObjectURL(u); };
    img.onerror = () => { resolve({ w: 300, h: 200 }); URL.revokeObjectURL(u); };
    img.src = u;
  });
}
