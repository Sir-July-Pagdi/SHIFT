import { startAutosave, flushSave } from './autosave';
import { openDocumentById } from './fileActions';
import { getSetting, listDocuments, requestPersistence, saveDocument, storageStatus } from './storage/db';
import { openDocument, starterDocument, useEditor } from './store';

/** Open the last document (or the newest, or a starter) and start autosave. */
export async function boot() {
  useEditor.setState({ reducedMotion: await getSetting('reducedMotion', false) });
  void requestPersistence().then(() => storageStatus()).then((storage) => useEditor.setState({ storage }));

  let opened = false;
  const last = await getSetting<string | null>('lastDocId', null);
  if (last) opened = await openDocumentById(last);
  if (!opened) {
    for (const row of await listDocuments()) { if (await openDocumentById(row.id)) { opened = true; break; } }
  }
  if (!opened) {
    const doc = starterDocument();
    await saveDocument(doc);
    openDocument(doc);
  }
  startAutosave();
  void flushSave();
}
