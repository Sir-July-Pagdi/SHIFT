import { createFromTemplate } from '@shift/document-model';
import { flushSave } from './autosave';
import { exportBundle, parseImport } from './storage/bundle';
import { deleteDocument, listDocuments, loadDocument, putAsset, recoveryCandidate, saveDocument, saveSnapshot } from './storage/db';
import { apply, getDoc, openDocument, toast, useEditor } from './store';

export async function openDocumentById(id: string): Promise<boolean> {
  await flushSave();
  const r = await loadDocument(id);
  if (!r.ok) {
    toast('That document is damaged and could not be opened');
    console.error('invalid document', r.errors);
    return false;
  }
  openDocument(r.doc);
  const rec = await recoveryCandidate(id);
  if (rec) useEditor.setState({ recovery: rec });
  return true;
}

export function acceptRecovery() {
  const rec = useEditor.getState().recovery;
  if (!rec) return;
  apply(() => rec);
  useEditor.setState({ recovery: null });
  toast('Recovered the newer version');
}
export async function dismissRecovery() {
  useEditor.setState({ recovery: null });
  await saveSnapshot(getDoc()); // newest snapshot now matches the saved document, so we stop asking
}

export async function createNewDocument() {
  await flushSave();
  const doc = createFromTemplate('blank').doc;
  await saveDocument(doc);
  openDocument(doc);
  toast('New presentation');
}

export async function removeDocument(id: string) {
  const wasCurrent = getDoc().id === id;
  await deleteDocument(id);
  if (wasCurrent) {
    const rest = await listDocuments();
    if (rest[0]) await openDocumentById(rest[0].id); else await createNewDocument();
  }
}

function download(name: string, blob: Blob) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

export async function exportCurrent() {
  await flushSave();
  const doc = getDoc();
  const bundle = await exportBundle(doc);
  const safe = doc.title.replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-') || 'presentation';
  download(`${safe}.shift.json`, new Blob([JSON.stringify(bundle)], { type: 'application/json' }));
  toast('Backup exported');
}

export async function importFile(file: File) {
  const r = await parseImport(await file.text());
  if (!r.ok) { toast(r.error); return; }
  await flushSave();
  const { doc, assets, warnings } = r.result;
  for (const a of assets) await putAsset({ id: a.id, docId: doc.id, name: a.name, mime: a.mime, blob: a.blob });
  await saveDocument(doc);
  openDocument(doc);
  toast(warnings.length ? `Imported with ${warnings.length} warning(s)` : 'Imported as a new presentation');
}
