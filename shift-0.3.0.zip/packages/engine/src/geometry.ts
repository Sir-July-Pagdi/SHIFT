import type { Point } from './camera';

const rad = (d: number) => (d * Math.PI) / 180;
const rotate = (p: Point, deg: number): Point => ({
  x: p.x * Math.cos(rad(deg)) - p.y * Math.sin(rad(deg)),
  y: p.x * Math.sin(rad(deg)) + p.y * Math.cos(rad(deg)),
});

export interface Box { x: number; y: number; w: number; h: number; rotation: number }
export type HandleId = 'nw' | 'ne' | 'se' | 'sw';
const SIGNS: Record<HandleId, [number, number]> = { nw: [-1, -1], ne: [1, -1], se: [1, 1], sw: [-1, 1] };

/**
 * Resize a (possibly rotated) box by dragging a corner handle to `pointer`
 * (world coordinates). The opposite corner stays fixed in world space.
 */
export function resizeBox(box: Box, handle: HandleId, pointer: Point, opts: { min?: number; keepRatio?: boolean } = {}): Box {
  const { min = 20, keepRatio = false } = opts;
  const [sx, sy] = SIGNS[handle];
  const c0 = { x: box.x + box.w / 2, y: box.y + box.h / 2 };
  const fixedOffset = rotate({ x: (-sx * box.w) / 2, y: (-sy * box.h) / 2 }, box.rotation);
  const fixed = { x: c0.x + fixedOffset.x, y: c0.y + fixedOffset.y };
  const v = rotate({ x: pointer.x - fixed.x, y: pointer.y - fixed.y }, -box.rotation);
  let w = Math.max(min, sx * v.x);
  let h = Math.max(min, sy * v.y);
  if (keepRatio) {
    const ratio = box.w / box.h;
    if (w / ratio > h) h = w / ratio; else w = h * ratio;
  }
  const c = rotate({ x: (sx * w) / 2, y: (sy * h) / 2 }, box.rotation);
  return { x: fixed.x + c.x - w / 2, y: fixed.y + c.y - h / 2, w, h, rotation: box.rotation };
}

/** Rotation (degrees, 0..360) so the box's "up" points at `pointer`. */
export function rotationToward(box: Box, pointer: Point, snap = false): number {
  const c = { x: box.x + box.w / 2, y: box.y + box.h / 2 };
  let deg = (Math.atan2(pointer.y - c.y, pointer.x - c.x) * 180) / Math.PI + 90;
  if (snap) deg = Math.round(deg / 15) * 15;
  return ((deg % 360) + 360) % 360;
}

export function handleWorldPosition(box: Box, handle: HandleId | 'rotate', rotateOffset = 30): Point {
  const c = { x: box.x + box.w / 2, y: box.y + box.h / 2 };
  const local = handle === 'rotate' ? { x: 0, y: -box.h / 2 - rotateOffset } : { x: (SIGNS[handle][0] * box.w) / 2, y: (SIGNS[handle][1] * box.h) / 2 };
  const r = rotate(local, box.rotation);
  return { x: c.x + r.x, y: c.y + r.y };
}
