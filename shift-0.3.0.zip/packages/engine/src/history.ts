/**
 * History engine: undo/redo over immutable snapshots.
 * Documents are updated immutably with structural sharing, so keeping 100
 * snapshots costs only the changed parts. Assets are not in the document.
 */
export interface History<T> { past: T[]; present: T; future: T[] }

export const HISTORY_LIMIT = 100;

export const createHistory = <T>(initial: T): History<T> => ({ past: [], present: initial, future: [] });
export const canUndo = (h: History<unknown>) => h.past.length > 0;
export const canRedo = (h: History<unknown>) => h.future.length > 0;

export function commit<T>(h: History<T>, next: T, limit = HISTORY_LIMIT): History<T> {
  if (next === h.present) return h;
  return { past: [...h.past, h.present].slice(-limit), present: next, future: [] };
}

/** Change the present without recording history (live preview during a drag). */
export const replacePresent = <T>(h: History<T>, next: T): History<T> => (next === h.present ? h : { ...h, present: next });

/** Finish a live gesture: record `base` (the state before the gesture) as one undo step. */
export function commitTransient<T>(h: History<T>, base: T, limit = HISTORY_LIMIT): History<T> {
  if (h.present === base) return h;
  return { past: [...h.past, base].slice(-limit), present: h.present, future: [] };
}

export function undo<T>(h: History<T>): History<T> {
  if (!h.past.length) return h;
  const previous = h.past[h.past.length - 1]!;
  return { past: h.past.slice(0, -1), present: previous, future: [h.present, ...h.future] };
}

export function redo<T>(h: History<T>): History<T> {
  if (!h.future.length) return h;
  const [next, ...rest] = h.future;
  return { past: [...h.past, h.present], present: next!, future: rest };
}
