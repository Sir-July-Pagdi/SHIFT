import type { EasingName, Rect } from '@shift/document-model';

/**
 * Camera engine. Pure maths: no DOM, no rendering library.
 *
 * x, y   = the world point shown at the centre of the viewport
 * zoom   = scale factor (1 = 100%)
 * rotation = degrees, clockwise
 *
 * The matching CSS is `translate(vw/2, vh/2) rotate(-rotation) scale(zoom) translate(-x, -y)`
 * (see cameraToCss), so world->screen is: centre + R(-rotation) * zoom * (world - (x, y)).
 */
export interface CameraState { x: number; y: number; zoom: number; rotation: number }
export interface Viewport { width: number; height: number }
export interface Point { x: number; y: number }

export const MIN_ZOOM = 0.05;
export const MAX_ZOOM = 8;

const rad = (deg: number) => (deg * Math.PI) / 180;
const rot = (p: Point, deg: number): Point => {
  const c = Math.cos(rad(deg));
  const s = Math.sin(rad(deg));
  return { x: p.x * c - p.y * s, y: p.x * s + p.y * c };
};

export const clampZoom = (z: number, min = MIN_ZOOM, max = MAX_ZOOM) => Math.max(min, Math.min(max, z));

export function worldToScreen(cam: CameraState, vp: Viewport, p: Point): Point {
  const r = rot({ x: (p.x - cam.x) * cam.zoom, y: (p.y - cam.y) * cam.zoom }, -cam.rotation);
  return { x: vp.width / 2 + r.x, y: vp.height / 2 + r.y };
}

export function screenToWorld(cam: CameraState, vp: Viewport, p: Point): Point {
  const r = rot({ x: (p.x - vp.width / 2) / cam.zoom, y: (p.y - vp.height / 2) / cam.zoom }, cam.rotation);
  return { x: cam.x + r.x, y: cam.y + r.y };
}

export function cameraToCss(cam: CameraState, vp: Viewport): string {
  return `translate(${vp.width / 2}px, ${vp.height / 2}px) rotate(${-cam.rotation}deg) scale(${cam.zoom}) translate(${-cam.x}px, ${-cam.y}px)`;
}

/** Zoom by `factor`, keeping the world point under `screenPt` fixed. */
export function zoomAt(cam: CameraState, vp: Viewport, screenPt: Point, factor: number): CameraState {
  const zoom = clampZoom(cam.zoom * factor);
  const w = screenToWorld(cam, vp, screenPt);
  const off = rot({ x: (screenPt.x - vp.width / 2) / zoom, y: (screenPt.y - vp.height / 2) / zoom }, cam.rotation);
  return { ...cam, zoom, x: w.x - off.x, y: w.y - off.y };
}

/** Pan by a screen-space delta (dragging the canvas by that many pixels). */
export function panBy(cam: CameraState, dxScreen: number, dyScreen: number): CameraState {
  const d = rot({ x: dxScreen / cam.zoom, y: dyScreen / cam.zoom }, cam.rotation);
  return { ...cam, x: cam.x - d.x, y: cam.y - d.y };
}

export interface FitOptions { padding?: number; minZoom?: number; maxZoom?: number; rotation?: number }

/** The camera that frames `rect` inside the viewport. */
export function cameraForRect(rect: Rect, vp: Viewport, opts: FitOptions = {}): CameraState {
  const { padding = 50, minZoom = MIN_ZOOM, maxZoom = 1.5, rotation = 0 } = opts;
  const availW = Math.max(1, vp.width - padding * 2);
  const availH = Math.max(1, vp.height - padding * 2);
  const zoom = clampZoom(Math.min(availW / Math.max(1, rect.w), availH / Math.max(1, rect.h)), minZoom, maxZoom);
  return { x: rect.x + rect.w / 2, y: rect.y + rect.h / 2, zoom, rotation };
}

export function boundsOf(rects: Rect[]): Rect | null {
  if (!rects.length) return null;
  const x1 = Math.min(...rects.map((r) => r.x));
  const y1 = Math.min(...rects.map((r) => r.y));
  const x2 = Math.max(...rects.map((r) => r.x + r.w));
  const y2 = Math.max(...rects.map((r) => r.y + r.h));
  return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
}

// ---- transitions -----------------------------------------------------------

export const EASINGS: Record<EasingName, (t: number) => number> = {
  linear: (t) => t,
  easeInOut: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
  easeOut: (t) => 1 - Math.pow(1 - t, 3),
};

const shortestAngle = (from: number, to: number) => ((((to - from) % 360) + 540) % 360) - 180;

/** Interpolate two cameras. Zoom moves geometrically so it feels even; rotation takes the short way. */
export function lerpCamera(a: CameraState, b: CameraState, t: number): CameraState {
  const k = Math.max(0, Math.min(1, t));
  return {
    x: a.x + (b.x - a.x) * k,
    y: a.y + (b.y - a.y) * k,
    zoom: a.zoom * Math.pow(b.zoom / a.zoom, k),
    rotation: a.rotation + shortestAngle(a.rotation, b.rotation) * k,
  };
}

/** Camera at `elapsedMs` into a transition. The caller owns the clock (rAF, tests, export). */
export function cameraAt(from: CameraState, to: CameraState, elapsedMs: number, durationMs: number, easing: EasingName): CameraState {
  if (durationMs <= 0 || elapsedMs >= durationMs) return to;
  return lerpCamera(from, to, EASINGS[easing](elapsedMs / durationMs));
}
