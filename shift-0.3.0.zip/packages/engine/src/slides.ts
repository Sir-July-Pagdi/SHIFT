import { createSlide, uid, type Rect, type SceneObject, type Slide, type ShiftDocument } from '@shift/document-model';
import { addObject, descendants } from './scene';

const touch = (doc: ShiftDocument): ShiftDocument => ({ ...doc, updatedAt: Date.now() });

export function addSlide(doc: ShiftDocument, name?: string): { doc: ShiftDocument; slideId: string } {
  const slide = createSlide(doc.slides.length, name);
  return { doc: touch({ ...doc, slides: [...doc.slides, slide] }), slideId: slide.id };
}

export function updateSlide(doc: ShiftDocument, slideId: string, patch: Partial<Omit<Slide, 'id'>>): ShiftDocument {
  return touch({ ...doc, slides: doc.slides.map((s) => (s.id === slideId ? { ...s, ...patch } : s)) });
}

export function removeSlide(doc: ShiftDocument, slideId: string): ShiftDocument {
  const objects = Object.fromEntries(Object.entries(doc.objects).filter(([, o]) => o.slideId !== slideId));
  const paths = doc.paths.map((p) => ({ ...p, steps: p.steps.filter((s) => !(s.target.kind === 'slide' && s.target.slideId === slideId)) }));
  return touch({ ...doc, slides: doc.slides.filter((s) => s.id !== slideId), objects, paths });
}

export function moveSlide(doc: ShiftDocument, from: number, to: number): ShiftDocument {
  if (from === to || from < 0 || to < 0 || from >= doc.slides.length || to >= doc.slides.length) return doc;
  const slides = doc.slides.slice();
  const [s] = slides.splice(from, 1);
  slides.splice(to, 0, s!);
  return touch({ ...doc, slides });
}

export function duplicateSlide(doc: ShiftDocument, slideId: string): { doc: ShiftDocument; slideId: string } | null {
  const idx = doc.slides.findIndex((s) => s.id === slideId);
  if (idx < 0) return null;
  const src = doc.slides[idx]!;
  const copy: Slide = { ...src, id: uid(), name: `${src.name} copy` };
  const slides = doc.slides.slice();
  slides.splice(idx + 1, 0, copy);
  let next = touch({ ...doc, slides });
  const objs = Object.values(doc.objects).filter((o) => o.slideId === slideId).sort((a, b) => a.z - b.z);
  for (const o of objs) next = addObject(next, { ...o, id: uid(), slideId: copy.id });
  return { doc: next, slideId: copy.id };
}

/**
 * Canvas frame -> slide. The frame stays on the canvas; its contents are copied
 * onto a new slide sized to the frame, positions made relative to the frame.
 * Limitation: nested frames inside the frame are not copied (slides have no frames),
 * and object rotation is preserved but the frame's own rotation is ignored.
 */
export function frameToSlide(doc: ShiftDocument, frameId: string): { doc: ShiftDocument; slideId: string } | null {
  const frame = doc.objects[frameId];
  if (!frame || frame.type !== 'frame') return null;
  const slide: Slide = {
    id: uid(), name: frame.text || 'Slide', width: Math.max(1, Math.round(frame.w)), height: Math.max(1, Math.round(frame.h)), notes: '',
  };
  let next = touch({ ...doc, slides: [...doc.slides, slide] });
  for (const o of descendants(doc, frameId).filter((d) => d.type !== 'frame').sort((a, b) => a.z - b.z)) {
    next = addObject(next, { ...o, id: uid(), x: o.x - frame.x, y: o.y - frame.y, parentId: null, slideId: slide.id });
  }
  return { doc: next, slideId: slide.id };
}

/** Slide -> canvas frame at `at`, containing copies of the slide's objects. The slide stays. */
export function slideToFrame(doc: ShiftDocument, slideId: string, at: Pick<Rect, 'x' | 'y'>): { doc: ShiftDocument; frameId: string } | null {
  const slide = doc.slides.find((s) => s.id === slideId);
  if (!slide) return null;
  const frame: SceneObject = {
    id: uid(), type: 'frame', x: at.x, y: at.y, w: slide.width, h: slide.height, rotation: 0, z: 0,
    fill: 'rgba(76,145,241,.04)', stroke: '#6ba8f7', color: '#a9cfff', fontSize: 15, bold: false,
    text: slide.name, parentId: null, slideId: null,
  };
  let next = addObject(doc, frame);
  for (const o of Object.values(doc.objects).filter((x) => x.slideId === slideId).sort((a, b) => a.z - b.z)) {
    next = addObject(next, { ...o, id: uid(), x: o.x + at.x, y: o.y + at.y, parentId: frame.id, slideId: null });
  }
  return { doc: next, frameId: frame.id };
}
