import { uid, type PathStep, type PresentationPath, type Rect, type ShiftDocument } from '@shift/document-model';
import { cameraForRect, type CameraState, type Viewport } from './camera';

const touch = (doc: ShiftDocument): ShiftDocument => ({ ...doc, updatedAt: Date.now() });

export const getActivePath = (doc: ShiftDocument): PresentationPath | null =>
  doc.paths.find((p) => p.id === doc.activePathId) ?? null;

/** Make sure there is an active path, creating "Main path" if needed. */
export function ensureActivePath(doc: ShiftDocument): ShiftDocument {
  if (getActivePath(doc)) return doc;
  if (doc.paths.length) return { ...doc, activePathId: doc.paths[0]!.id };
  const path: PresentationPath = { id: uid(), name: 'Main path', steps: [] };
  return { ...doc, paths: [path], activePathId: path.id };
}

const mapActive = (doc: ShiftDocument, fn: (p: PresentationPath) => PresentationPath): ShiftDocument => {
  const d = ensureActivePath(doc);
  return touch({ ...d, paths: d.paths.map((p) => (p.id === d.activePathId ? fn(p) : p)) });
};

export const newFrameStep = (frameId: string): PathStep => ({
  id: uid(), target: { kind: 'frame', frameId }, duration: 900, easing: 'easeInOut',
});

export const addFrameStep = (doc: ShiftDocument, frameId: string): ShiftDocument =>
  mapActive(doc, (p) => (p.steps.some((s) => s.target.kind === 'frame' && s.target.frameId === frameId) ? p : { ...p, steps: [...p.steps, newFrameStep(frameId)] }));

export function moveStep(doc: ShiftDocument, from: number, to: number): ShiftDocument {
  return mapActive(doc, (p) => {
    if (from === to || from < 0 || to < 0 || from >= p.steps.length || to >= p.steps.length) return p;
    const steps = p.steps.slice();
    const [s] = steps.splice(from, 1);
    steps.splice(to, 0, s!);
    return { ...p, steps };
  });
}

export const removeStep = (doc: ShiftDocument, stepId: string): ShiftDocument =>
  mapActive(doc, (p) => ({ ...p, steps: p.steps.filter((s) => s.id !== stepId) }));

export const updateStep = (doc: ShiftDocument, stepId: string, patch: Partial<Pick<PathStep, 'duration' | 'easing'>>): ShiftDocument =>
  mapActive(doc, (p) => ({ ...p, steps: p.steps.map((s) => (s.id === stepId ? { ...s, ...patch } : s)) }));

/** Multiple paths through one document (e.g. a different order per class). Starts as a copy of the active path. */
export function createPath(doc: ShiftDocument, name: string): ShiftDocument {
  const d = ensureActivePath(doc);
  const src = getActivePath(d)!;
  const path: PresentationPath = { id: uid(), name, steps: src.steps.map((s) => ({ ...s, id: uid() })) };
  return touch({ ...d, paths: [...d.paths, path], activePathId: path.id });
}

export const setActivePath = (doc: ShiftDocument, pathId: string): ShiftDocument =>
  doc.paths.some((p) => p.id === pathId) ? { ...doc, activePathId: pathId } : doc;

export function renamePath(doc: ShiftDocument, pathId: string, name: string): ShiftDocument {
  return touch({ ...doc, paths: doc.paths.map((p) => (p.id === pathId ? { ...p, name } : p)) });
}

export function deletePath(doc: ShiftDocument, pathId: string): ShiftDocument {
  if (doc.paths.length <= 1) return doc; // never leave the document without a path
  const paths = doc.paths.filter((p) => p.id !== pathId);
  return touch({ ...doc, paths, activePathId: doc.activePathId === pathId ? paths[0]!.id : doc.activePathId });
}

// ---- resolution ------------------------------------------------------------

export interface ResolvedStep {
  step: PathStep;
  space: { kind: 'canvas' } | { kind: 'slide'; slideId: string };
  rect: Rect;
  label: string;
}

/** Turn path steps into renderable destinations; steps whose target vanished are skipped. */
export function resolveSteps(doc: ShiftDocument, steps: PathStep[]): ResolvedStep[] {
  const out: ResolvedStep[] = [];
  for (const step of steps) {
    if (step.target.kind === 'frame') {
      const f = doc.objects[step.target.frameId];
      if (f?.type === 'frame') out.push({ step, space: { kind: 'canvas' }, rect: { x: f.x, y: f.y, w: f.w, h: f.h }, label: f.text || 'Topic' });
    } else {
      const slideId = step.target.slideId;
      const s = doc.slides.find((x) => x.id === slideId);
      if (s) out.push({ step, space: { kind: 'slide', slideId: s.id }, rect: { x: 0, y: 0, w: s.width, h: s.height }, label: s.name });
    }
  }
  return out;
}

/** Slides are inherently ordered: slide shows use an implicit path over them. */
export function slideShowSteps(doc: ShiftDocument): PathStep[] {
  return doc.slides.map((s) => ({ id: `slide-${s.id}`, target: { kind: 'slide', slideId: s.id }, duration: 0, easing: 'linear' }));
}

export function cameraForStep(r: ResolvedStep, vp: Viewport): CameraState {
  return r.space.kind === 'slide'
    ? cameraForRect(r.rect, vp, { padding: 0, maxZoom: 4 })
    : cameraForRect(r.rect, vp, { padding: 24, maxZoom: 4 });
}
