import { createObject, uid, type ObjectType, type SceneObject, type ShiftDocument } from '@shift/document-model';
import { addFrameStep } from './paths';

const touch = (doc: ShiftDocument): ShiftDocument => ({ ...doc, updatedAt: Date.now() });

export const getObject = (doc: ShiftDocument, id: string): SceneObject | undefined => doc.objects[id];

/** Objects in one space (canvas = null), back to front. */
export function objectsInSpace(doc: ShiftDocument, slideId: string | null): SceneObject[] {
  return Object.values(doc.objects).filter((o) => o.slideId === slideId).sort((a, b) => a.z - b.z);
}

export const frames = (doc: ShiftDocument): SceneObject[] => Object.values(doc.objects).filter((o) => o.type === 'frame');

const maxZ = (doc: ShiftDocument, slideId: string | null) => {
  const zs = objectsInSpace(doc, slideId).map((o) => o.z);
  return zs.length ? Math.max(...zs) : -1;
};

/** All objects contained (transitively) in `id`, excluding `id` itself. */
export function descendants(doc: ShiftDocument, id: string): SceneObject[] {
  const out: SceneObject[] = [];
  const stack = [id];
  const seen = new Set<string>([id]);
  const all = Object.values(doc.objects);
  while (stack.length) {
    const cur = stack.pop()!;
    for (const o of all) {
      if (o.parentId === cur && !seen.has(o.id)) { seen.add(o.id); out.push(o); stack.push(o.id); }
    }
  }
  return out;
}

/** `ids` plus everything inside any frame in `ids`. */
export function withDescendants(doc: ShiftDocument, ids: string[]): string[] {
  const set = new Set<string>(ids.filter((i) => doc.objects[i]));
  for (const id of [...set]) for (const d of descendants(doc, id)) set.add(d.id);
  return [...set];
}

/** Ids in `ids` that are not inside another member of `ids`. */
export function topLevel(doc: ShiftDocument, ids: string[]): string[] {
  const set = new Set(ids);
  return ids.filter((id) => {
    let p = doc.objects[id]?.parentId ?? null;
    while (p) { if (set.has(p)) return false; p = doc.objects[p]?.parentId ?? null; }
    return true;
  });
}

export function addObject(doc: ShiftDocument, obj: SceneObject): ShiftDocument {
  const o: SceneObject = { ...obj, z: maxZ(doc, obj.slideId) + 1 };
  let next = touch({ ...doc, objects: { ...doc.objects, [o.id]: o } });
  if (o.type === 'frame') next = addFrameStep(next, o.id);
  return next;
}

export function makeObject(type: ObjectType, at: { x: number; y: number }, slideId: string | null, extra: Partial<SceneObject> = {}): SceneObject {
  const o = createObject(type, { slideId, ...extra });
  // Slides are white paper: default text must be dark there (the prototype used light text everywhere).
  if (slideId !== null && type === 'text' && extra.color === undefined) o.color = '#17243a';
  return { ...o, x: at.x - o.w / 2, y: at.y - o.h / 2 };
}

export function updateObject(doc: ShiftDocument, id: string, patch: Partial<SceneObject>): ShiftDocument {
  const cur = doc.objects[id];
  if (!cur) return doc;
  return touch({ ...doc, objects: { ...doc.objects, [id]: { ...cur, ...patch, id: cur.id, type: cur.type } } });
}

/** Move objects by (dx, dy). Frames carry their contents. */
export function moveObjects(doc: ShiftDocument, ids: string[], dx: number, dy: number): ShiftDocument {
  const all = withDescendants(doc, ids);
  if (!all.length || (dx === 0 && dy === 0)) return doc;
  const objects = { ...doc.objects };
  for (const id of all) { const o = objects[id]!; objects[id] = { ...o, x: o.x + dx, y: o.y + dy }; }
  return touch({ ...doc, objects });
}

/**
 * Recompute which frame (if any) contains this object. Non-frames: the smallest
 * frame containing their centre. Frames: the smallest larger frame that fully
 * contains them. Never parents an object to itself or its own descendants.
 */
export function autoParent(doc: ShiftDocument, id: string): ShiftDocument {
  const o = doc.objects[id];
  if (!o || o.slideId !== null) return doc;
  const banned = new Set([id, ...descendants(doc, id).map((d) => d.id)]);
  let best: SceneObject | null = null;
  for (const f of frames(doc)) {
    if (banned.has(f.id)) continue;
    const inside = o.type === 'frame'
      ? o.x >= f.x && o.y >= f.y && o.x + o.w <= f.x + f.w && o.y + o.h <= f.y + f.h && f.w * f.h > o.w * o.h
      : o.x + o.w / 2 >= f.x && o.x + o.w / 2 <= f.x + f.w && o.y + o.h / 2 >= f.y && o.y + o.h / 2 <= f.y + f.h;
    if (inside && (!best || f.w * f.h < best.w * best.h)) best = f;
  }
  const parentId = best?.id ?? null;
  return parentId === o.parentId ? doc : updateObject(doc, id, { parentId });
}

/**
 * Delete objects. Deleting a frame keeps its contents (they are re-parented to
 * the frame's own parent) and removes the path steps that targeted it.
 */
export function removeObjects(doc: ShiftDocument, ids: string[]): ShiftDocument {
  const kill = new Set(ids.filter((i) => doc.objects[i]));
  if (!kill.size) return doc;
  const objects: Record<string, SceneObject> = {};
  for (const [id, o] of Object.entries(doc.objects)) {
    if (kill.has(id)) continue;
    let parent = o.parentId;
    while (parent && kill.has(parent)) parent = doc.objects[parent]?.parentId ?? null;
    objects[id] = parent === o.parentId ? o : { ...o, parentId: parent };
  }
  const paths = doc.paths.map((p) => ({
    ...p,
    steps: p.steps.filter((s) => !(s.target.kind === 'frame' && kill.has(s.target.frameId))),
  }));
  return touch({ ...doc, objects, paths });
}

/** Duplicate objects (with contents), offset by 28 units. Returns the new top-level ids. */
export function duplicateObjects(doc: ShiftDocument, ids: string[]): { doc: ShiftDocument; ids: string[] } {
  const all = withDescendants(doc, ids);
  const idMap = new Map(all.map((id) => [id, uid()]));
  let next = doc;
  const roots = topLevel(doc, ids.filter((i) => doc.objects[i]));
  const copies = all.map((id) => doc.objects[id]!).sort((a, b) => a.z - b.z);
  for (const o of copies) {
    const isRoot = roots.includes(o.id);
    const copy: SceneObject = {
      ...o,
      id: idMap.get(o.id)!,
      x: o.x + 28, y: o.y + 28,
      parentId: o.parentId && idMap.has(o.parentId) ? idMap.get(o.parentId)! : o.parentId,
    };
    next = addObject(next, copy);
    if (isRoot && copy.parentId === o.parentId) next = autoParent(next, copy.id);
  }
  return { doc: next, ids: roots.map((r) => idMap.get(r)!) };
}

/** Swap z with the neighbour in the same space. */
export function stepZ(doc: ShiftDocument, id: string, dir: 1 | -1): ShiftDocument {
  const o = doc.objects[id];
  if (!o) return doc;
  const list = objectsInSpace(doc, o.slideId);
  const i = list.findIndex((x) => x.id === id);
  const j = i + dir;
  if (j < 0 || j >= list.length) return doc;
  const other = list[j]!;
  const objects = { ...doc.objects, [o.id]: { ...o, z: other.z }, [other.id]: { ...other, z: o.z } };
  // equal z values would make the swap a no-op: normalise if needed
  if (o.z === other.z) objects[o.id] = { ...o, z: other.z + dir };
  return touch({ ...doc, objects });
}

export function reorderZ(doc: ShiftDocument, id: string, where: 'front' | 'back'): ShiftDocument {
  const o = doc.objects[id];
  if (!o) return doc;
  const zs = objectsInSpace(doc, o.slideId).map((x) => x.z);
  return updateObject(doc, id, { z: where === 'front' ? Math.max(...zs) + 1 : Math.min(...zs) - 1 });
}

/** Re-evaluate containment for every canvas object (used after a frame is resized). */
export function reparentAll(doc: ShiftDocument): ShiftDocument {
  let next = doc;
  // larger frames first, so nested frames resolve against up-to-date parents
  const ordered = Object.values(doc.objects).filter((o) => o.slideId === null).sort((a, b) => b.w * b.h - a.w * a.h);
  for (const o of ordered) next = autoParent(next, o.id);
  return next;
}
