import { describe, expect, it } from 'vitest';
import { createDocument, createFromTemplate, validateDocument, type ShiftDocument } from '@shift/document-model';
import {
  addObject, addSlide, autoParent, boundsOf, cameraAt, cameraForRect, commit, commitTransient, createHistory,
  createPath, deletePath, descendants, duplicateObjects, duplicateSlide, frameToSlide, getActivePath, lerpCamera,
  makeObject, moveObjects, moveSlide, moveStep, objectsInSpace, panBy, redo, removeObjects, removeSlide, replacePresent,
  resolveSteps, resizeBox, rotationToward, screenToWorld, slideToFrame, stepZ, undo, updateObject, worldToScreen, zoomAt,
  slideShowSteps, canUndo, canRedo, setActivePath, updateStep, reparentAll,
} from '../src';

const vp = { width: 1000, height: 600 };
const ok = (doc: ShiftDocument) => { const r = validateDocument(doc); expect(r.ok, r.ok ? '' : r.errors.join('; ')).toBe(true); };

describe('camera', () => {
  it('worldToScreen and screenToWorld are inverses, including rotation', () => {
    for (const rotation of [0, 30, 90, -45]) {
      const cam = { x: 120, y: -40, zoom: 1.7, rotation };
      const p = { x: 333, y: 77 };
      const back = screenToWorld(cam, vp, worldToScreen(cam, vp, p));
      expect(back.x).toBeCloseTo(p.x, 6);
      expect(back.y).toBeCloseTo(p.y, 6);
    }
  });
  it('camera centre maps to the viewport centre', () => {
    const s = worldToScreen({ x: 10, y: 20, zoom: 2, rotation: 0 }, vp, { x: 10, y: 20 });
    expect(s).toEqual({ x: 500, y: 300 });
  });
  it('zoomAt keeps the point under the cursor fixed', () => {
    const cam = { x: 0, y: 0, zoom: 1, rotation: 20 };
    const pt = { x: 700, y: 120 };
    const before = screenToWorld(cam, vp, pt);
    const z = zoomAt(cam, vp, pt, 1.5);
    const after = screenToWorld(z, vp, pt);
    expect(z.zoom).toBeCloseTo(1.5);
    expect(after.x).toBeCloseTo(before.x, 6);
    expect(after.y).toBeCloseTo(before.y, 6);
  });
  it('panBy moves the world with the pointer', () => {
    const cam = { x: 0, y: 0, zoom: 2, rotation: 0 };
    const p = worldToScreen(cam, vp, { x: 5, y: 5 });
    const moved = panBy(cam, 40, -10);
    const p2 = worldToScreen(moved, vp, { x: 5, y: 5 });
    expect(p2.x - p.x).toBeCloseTo(40);
    expect(p2.y - p.y).toBeCloseTo(-10);
  });
  it('cameraForRect frames the whole rect', () => {
    const rect = { x: 100, y: 100, w: 800, h: 200 };
    const cam = cameraForRect(rect, vp, { padding: 20, maxZoom: 10 });
    const tl = worldToScreen(cam, vp, { x: rect.x, y: rect.y });
    const br = worldToScreen(cam, vp, { x: rect.x + rect.w, y: rect.y + rect.h });
    expect(tl.x).toBeGreaterThanOrEqual(19.999);
    expect(br.x).toBeLessThanOrEqual(vp.width - 19.999);
    expect(br.y).toBeLessThanOrEqual(vp.height);
  });
  it('lerp hits endpoints, zoom is geometric, rotation takes the short way', () => {
    const a = { x: 0, y: 0, zoom: 1, rotation: 350 };
    const b = { x: 100, y: 0, zoom: 4, rotation: 10 };
    expect(lerpCamera(a, b, 0)).toEqual(a);
    const mid = lerpCamera(a, b, 0.5);
    expect(mid.zoom).toBeCloseTo(2);
    expect(mid.x).toBeCloseTo(50);
    expect(((mid.rotation % 360) + 360) % 360).toBeCloseTo(0);
    expect(lerpCamera(a, b, 1).zoom).toBeCloseTo(4);
  });
  it('cameraAt: zero duration jumps, end of duration lands exactly', () => {
    const a = { x: 0, y: 0, zoom: 1, rotation: 0 };
    const b = { x: 10, y: 10, zoom: 2, rotation: 0 };
    expect(cameraAt(a, b, 0, 0, 'linear')).toBe(b);
    expect(cameraAt(a, b, 900, 900, 'easeInOut')).toBe(b);
    const half = cameraAt(a, b, 450, 900, 'easeInOut');
    expect(half.x).toBeCloseTo(5);
  });
  it('boundsOf', () => {
    expect(boundsOf([])).toBeNull();
    expect(boundsOf([{ x: 0, y: 0, w: 10, h: 10 }, { x: 20, y: 5, w: 10, h: 10 }])).toEqual({ x: 0, y: 0, w: 30, h: 15 });
  });
});

describe('history', () => {
  it('commit, undo, redo; new commit clears redo', () => {
    let h = createHistory(1);
    h = commit(h, 2); h = commit(h, 3);
    expect(h.present).toBe(3);
    h = undo(h); expect(h.present).toBe(2);
    expect(canRedo(h)).toBe(true);
    h = redo(h); expect(h.present).toBe(3);
    h = undo(h); h = commit(h, 9);
    expect(canRedo(h)).toBe(false);
    expect(canUndo(h)).toBe(true);
  });
  it('committing an identical value is a no-op', () => {
    const h = createHistory({ a: 1 });
    expect(commit(h, h.present)).toBe(h);
  });
  it('a live gesture becomes exactly one undo step', () => {
    let h = createHistory('start');
    const base = h.present;
    h = replacePresent(h, 'a'); h = replacePresent(h, 'b'); h = replacePresent(h, 'c');
    h = commitTransient(h, base);
    expect(h.past).toEqual(['start']);
    expect(undo(h).present).toBe('start');
  });
  it('respects the limit', () => {
    let h = createHistory(0);
    for (let i = 1; i <= 10; i++) h = commit(h, i, 3);
    expect(h.past).toHaveLength(3);
  });
});

describe('scene', () => {
  const setup = () => {
    let doc = createDocument();
    const frame = makeObject('frame', { x: 300, y: 200 }, null);
    doc = addObject(doc, frame);
    const t = makeObject('text', { x: 300, y: 200 }, null);
    doc = addObject(doc, t);
    doc = autoParent(doc, t.id);
    return { doc, frame, t };
  };

  it('adding a frame appends a path step; adding other objects does not', () => {
    const { doc, frame } = setup();
    expect(getActivePath(doc)!.steps).toHaveLength(1);
    expect(getActivePath(doc)!.steps[0]!.target).toEqual({ kind: 'frame', frameId: frame.id });
    ok(doc);
  });

  it('autoParent puts an object inside the smallest containing frame', () => {
    const { doc, frame, t } = setup();
    expect(doc.objects[t.id]!.parentId).toBe(frame.id);
    // inner frame
    const inner = makeObject('frame', { x: 300, y: 200 }, null, { w: 100, h: 80 });
    let d = addObject(doc, inner);
    d = autoParent(d, inner.id);
    expect(d.objects[inner.id]!.parentId).toBe(frame.id);
    d = autoParent(d, t.id);
    expect(d.objects[t.id]!.parentId).toBe(inner.id); // text centre is inside the smaller frame
    ok(d);
  });

  it('moving a frame carries its contents; moving a child does not move the frame', () => {
    const { doc, frame, t } = setup();
    const moved = moveObjects(doc, [frame.id], 100, 50);
    expect(moved.objects[t.id]!.x).toBe(doc.objects[t.id]!.x + 100);
    expect(moved.objects[frame.id]!.y).toBe(doc.objects[frame.id]!.y + 50);
    const child = moveObjects(doc, [t.id], 10, 10);
    expect(child.objects[frame.id]).toBe(doc.objects[frame.id]);
  });

  it('dragging a child out of its frame un-parents it', () => {
    const { doc, t, frame } = setup();
    let d = moveObjects(doc, [t.id], 2000, 2000);
    d = autoParent(d, t.id);
    expect(d.objects[t.id]!.parentId).toBeNull();
    expect(d.objects[frame.id]!.parentId).toBeNull();
  });

  it('does not double-move when a frame and its child are both selected', () => {
    const { doc, frame, t } = setup();
    const moved = moveObjects(doc, [frame.id, t.id], 10, 0);
    expect(moved.objects[t.id]!.x).toBe(doc.objects[t.id]!.x + 10);
  });

  it('deleting a frame keeps its contents and removes its path step', () => {
    const { doc, frame, t } = setup();
    const d = removeObjects(doc, [frame.id]);
    expect(d.objects[frame.id]).toBeUndefined();
    expect(d.objects[t.id]).toBeDefined();
    expect(d.objects[t.id]!.parentId).toBeNull();
    expect(getActivePath(d)!.steps).toHaveLength(0);
    ok(d);
  });

  it('deleting a nested frame re-parents contents to the grandparent', () => {
    const { doc, frame, t } = setup();
    const inner = makeObject('frame', { x: 300, y: 200 }, null, { w: 100, h: 80 });
    let d = addObject(doc, inner);
    d = autoParent(d, inner.id); d = autoParent(d, t.id);
    d = removeObjects(d, [inner.id]);
    expect(d.objects[t.id]!.parentId).toBe(frame.id);
    ok(d);
  });

  it('duplicate copies a frame with its contents and keeps the document valid', () => {
    const { doc, frame } = setup();
    const { doc: d, ids } = duplicateObjects(doc, [frame.id]);
    expect(ids).toHaveLength(1);
    expect(Object.keys(d.objects)).toHaveLength(4);
    const copy = d.objects[ids[0]!]!;
    expect(descendants(d, copy.id)).toHaveLength(1);
    expect(getActivePath(d)!.steps).toHaveLength(2);
    ok(d);
  });

  it('reparentAll picks up objects swallowed by a resized frame', () => {
    const { doc, frame } = setup();
    const far = makeObject('rect', { x: 1200, y: 200 }, null);
    let d = addObject(doc, far);
    d = autoParent(d, far.id);
    expect(d.objects[far.id]!.parentId).toBeNull();
    d = updateObject(d, frame.id, { w: 2000 });
    d = reparentAll(d);
    expect(d.objects[far.id]!.parentId).toBe(frame.id);
    ok(d);
  });

  it('z-order: new objects go on top, stepZ swaps neighbours', () => {
    let d = createDocument();
    const a = makeObject('rect', { x: 0, y: 0 }, null);
    const b = makeObject('rect', { x: 0, y: 0 }, null);
    d = addObject(d, a); d = addObject(d, b);
    expect(objectsInSpace(d, null).map((o) => o.id)).toEqual([a.id, b.id]);
    d = stepZ(d, a.id, 1);
    expect(objectsInSpace(d, null).map((o) => o.id)).toEqual([b.id, a.id]);
  });

  it('updateObject cannot change id or type', () => {
    const { doc, t } = setup();
    const d = updateObject(doc, t.id, { id: 'x', type: 'rect', text: 'hi' } as never);
    expect(d.objects[t.id]!.type).toBe('text');
    expect(d.objects[t.id]!.text).toBe('hi');
  });

  it('100+ objects keep the document valid through moves, duplicates and deletes', () => {
    let d = createDocument();
    const frame = makeObject('frame', { x: 400, y: 300 }, null, { w: 2000, h: 1500 });
    d = addObject(d, frame);
    const ids: string[] = [];
    for (let i = 0; i < 150; i++) {
      const o = makeObject(i % 3 === 0 ? 'text' : i % 3 === 1 ? 'rect' : 'circle', { x: 100 + (i % 15) * 120, y: 100 + Math.floor(i / 15) * 100 }, null);
      d = addObject(d, o); d = autoParent(d, o.id); ids.push(o.id);
    }
    ok(d);
    d = moveObjects(d, [frame.id], 500, 500);
    d = duplicateObjects(d, ids.slice(0, 40)).doc;
    d = removeObjects(d, ids.slice(40, 80));
    expect(Object.keys(d.objects).length).toBe(1 + 150 + 40 - 40);
    ok(d);
  });
});

describe('paths', () => {
  it('reorders, edits and resolves steps; steps with deleted targets are skipped', () => {
    const { doc } = createFromTemplate('lesson');
    const steps = getActivePath(doc)!.steps;
    expect(steps).toHaveLength(3);
    const moved = moveStep(doc, 0, 2);
    expect(getActivePath(moved)!.steps[2]!.id).toBe(steps[0]!.id);
    const timed = updateStep(moved, steps[1]!.id, { duration: 300, easing: 'easeOut' });
    expect(getActivePath(timed)!.steps.find((s) => s.id === steps[1]!.id)).toMatchObject({ duration: 300, easing: 'easeOut' });
    expect(resolveSteps(timed, getActivePath(timed)!.steps)).toHaveLength(3);
    ok(timed);
  });

  it('supports multiple paths through the same document', () => {
    const { doc } = createFromTemplate('lesson');
    let d = createPath(doc, 'Class B');
    expect(d.paths).toHaveLength(2);
    d = moveStep(d, 0, 2); // reorder Class B only
    const [a, b] = d.paths;
    expect(a!.steps.map((s) => s.id)).not.toEqual(b!.steps.map((s) => s.id));
    const reordered = d.paths[1]!;
    expect(d.activePathId).toBe(reordered.id);
    d = setActivePath(d, a!.id);
    expect(getActivePath(d)!.name).toBe('Main path');
    d = deletePath(d, reordered.id);
    expect(d.paths).toHaveLength(1);
    expect(deletePath(d, d.paths[0]!.id).paths).toHaveLength(1); // never zero paths
    ok(d);
  });

  it('slide shows are an implicit ordered path over slides', () => {
    const { doc } = createFromTemplate('pitch');
    const steps = slideShowSteps(doc);
    expect(steps).toHaveLength(5);
    expect(resolveSteps(doc, steps).map((r) => r.label)[0]).toBe('1. The opportunity');
  });
});

describe('slides and canvas/slide conversion', () => {
  it('add, reorder, duplicate, remove', () => {
    let d = createDocument();
    const a = addSlide(d); d = a.doc;
    const b = addSlide(d); d = b.doc;
    d = addObject(d, makeObject('text', { x: 100, y: 100 }, a.slideId));
    d = moveSlide(d, 0, 1);
    expect(d.slides[1]!.id).toBe(a.slideId);
    const dup = duplicateSlide(d, a.slideId)!;
    expect(dup.doc.slides).toHaveLength(3);
    expect(objectsInSpace(dup.doc, dup.slideId)).toHaveLength(1);
    const removed = removeSlide(dup.doc, a.slideId);
    expect(objectsInSpace(removed, a.slideId)).toHaveLength(0);
    ok(removed);
  });

  it('frame -> slide copies contents relative to the frame', () => {
    const { doc } = createFromTemplate('lesson');
    const frame = Object.values(doc.objects).find((o) => o.type === 'frame')!;
    const res = frameToSlide(doc, frame.id)!;
    const slide = res.doc.slides.find((s) => s.id === res.slideId)!;
    expect(slide.width).toBe(frame.w);
    const onSlide = objectsInSpace(res.doc, res.slideId);
    expect(onSlide.length).toBe(descendants(doc, frame.id).length);
    expect(onSlide.every((o) => o.x >= 0 && o.y >= 0 && o.x < slide.width)).toBe(true);
    expect(res.doc.objects[frame.id]).toBe(doc.objects[frame.id]); // frame untouched
    ok(res.doc);
  });

  it('slide -> frame -> slide round trip preserves content text and layout', () => {
    const { doc } = createFromTemplate('pitch');
    const first = doc.slides[0]!;
    const toFrame = slideToFrame(doc, first.id, { x: 5000, y: 0 })!;
    const frame = toFrame.doc.objects[toFrame.frameId]!;
    expect(frame.w).toBe(first.width);
    expect(descendants(toFrame.doc, frame.id)).toHaveLength(objectsInSpace(doc, first.id).length);
    const back = frameToSlide(toFrame.doc, frame.id)!;
    const orig = objectsInSpace(doc, first.id).map((o) => [o.text, o.x, o.y]);
    const round = objectsInSpace(back.doc, back.slideId).map((o) => [o.text, o.x, o.y]);
    expect(round).toEqual(orig);
    ok(back.doc);
  });
});

describe('geometry', () => {
  it('resizing an unrotated box from the SE corner', () => {
    const r = resizeBox({ x: 0, y: 0, w: 100, h: 100, rotation: 0 }, 'se', { x: 200, y: 150 });
    expect(r).toMatchObject({ x: 0, y: 0, w: 200, h: 150 });
  });
  it('resizing from NW keeps the opposite corner fixed', () => {
    const r = resizeBox({ x: 100, y: 100, w: 100, h: 100, rotation: 0 }, 'nw', { x: 50, y: 60 });
    expect(r).toMatchObject({ x: 50, y: 60, w: 150, h: 140 });
  });
  it('rotated resize keeps the opposite corner fixed in world space', () => {
    const box = { x: 100, y: 100, w: 200, h: 100, rotation: 90 };
    const corner = (b: typeof box) => {
      const c = { x: b.x + b.w / 2, y: b.y + b.h / 2 };
      // NW corner local (-w/2,-h/2) rotated by 90deg
      const l = { x: -b.w / 2, y: -b.h / 2 };
      const rad = (b.rotation * Math.PI) / 180;
      return { x: c.x + l.x * Math.cos(rad) - l.y * Math.sin(rad), y: c.y + l.x * Math.sin(rad) + l.y * Math.cos(rad) };
    };
    const before = corner(box);
    const out = resizeBox(box, 'se', { x: 400, y: 500 });
    const after = corner(out);
    expect(after.x).toBeCloseTo(before.x, 6);
    expect(after.y).toBeCloseTo(before.y, 6);
  });
  it('respects the minimum size and ratio lock', () => {
    const r = resizeBox({ x: 0, y: 0, w: 100, h: 100, rotation: 0 }, 'se', { x: -50, y: -50 }, { min: 20 });
    expect(r.w).toBe(20);
    const k = resizeBox({ x: 0, y: 0, w: 200, h: 100, rotation: 0 }, 'se', { x: 400, y: 120 }, { keepRatio: true });
    expect(k.w / k.h).toBeCloseTo(2);
  });
  it('rotationToward points up at 0 and right at 90, with snapping', () => {
    const box = { x: 0, y: 0, w: 100, h: 100, rotation: 0 };
    expect(rotationToward(box, { x: 50, y: -100 })).toBeCloseTo(0);
    expect(rotationToward(box, { x: 300, y: 50 })).toBeCloseTo(90);
    expect(rotationToward(box, { x: 300, y: 80 }, true) % 15).toBe(0);
  });
});
