import {
  SCHEMA_VERSION, type ObjectType, type SceneObject, type ShiftDocument, type Slide,
} from './types';

export const DEFAULT_SLIDE_WIDTH = 960;
export const DEFAULT_SLIDE_HEIGHT = 540;

export function uid(): string {
  const c = (globalThis as { crypto?: Crypto }).crypto;
  if (c?.randomUUID) return c.randomUUID().replace(/-/g, '').slice(0, 12);
  return Math.random().toString(36).slice(2, 14).padEnd(12, '0');
}

export function createDocument(title = 'Untitled presentation'): ShiftDocument {
  const now = Date.now();
  return {
    schemaVersion: SCHEMA_VERSION,
    id: uid(),
    title,
    createdAt: now,
    updatedAt: now,
    theme: { name: 'Shift Dark', accent: '#4b91f1', fontFamily: 'system-ui, sans-serif' },
    objects: {},
    slides: [],
    paths: [],
    activePathId: null,
    assets: {},
  };
}

export function createSlide(index: number, name?: string): Slide {
  return {
    id: uid(),
    name: name ?? `Slide ${index + 1}`,
    width: DEFAULT_SLIDE_WIDTH,
    height: DEFAULT_SLIDE_HEIGHT,
    notes: '',
  };
}

const BASE: Omit<SceneObject, 'id' | 'type'> = {
  x: 0, y: 0, w: 220, h: 100, rotation: 0, z: 0,
  fill: '#e8f1ff', stroke: '#8bb7ef', color: '#17243a', fontSize: 28, bold: false,
  text: '', parentId: null, slideId: null,
};

/** Defaults per object type (ported from the 0.2 prototype). */
export function createObject(type: ObjectType, overrides: Partial<SceneObject> = {}): SceneObject {
  const o: SceneObject = { ...BASE, id: uid(), type };
  switch (type) {
    case 'text':
      Object.assign(o, { w: 330, h: 90, text: 'Double-click to edit', fill: 'transparent', fontSize: 32, color: '#f1f6ff' });
      break;
    case 'card':
      Object.assign(o, { w: 300, h: 190, fill: '#ffffff', text: 'A clear idea\nstarts with a strong message.', fontSize: 26, color: '#182a44' });
      break;
    case 'rect':
      Object.assign(o, { w: 180, h: 120, fill: '#dbeafe' });
      break;
    case 'circle':
      Object.assign(o, { w: 120, h: 120, fill: '#9bc4ff' });
      break;
    case 'frame':
      Object.assign(o, { w: 480, h: 300, fill: 'rgba(76,145,241,.04)', stroke: '#6ba8f7', text: 'New topic', fontSize: 15 });
      break;
    case 'image':
      Object.assign(o, { w: 300, h: 200 });
      break;
  }
  return { ...o, ...overrides, id: overrides.id ?? o.id, type };
}
