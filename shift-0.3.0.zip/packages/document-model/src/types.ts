/**
 * SHIFT document model (schema v1).
 *
 * Pure data. No React, no DOM, no rendering-library types. Everything here must
 * survive JSON.stringify -> JSON.parse unchanged, so any renderer (DOM today,
 * Konva/Pixi later), the presenter, the exporter and a future cloud service can
 * all consume the same document.
 */
export const SCHEMA_VERSION = 1 as const;

export type ObjectType = 'text' | 'card' | 'rect' | 'circle' | 'frame' | 'image';
export const OBJECT_TYPES: readonly ObjectType[] = ['text', 'card', 'rect', 'circle', 'frame', 'image'];

export interface SceneObject {
  id: string;
  type: ObjectType;
  /** Position of the top-left corner (before rotation), in the object's space. */
  x: number;
  y: number;
  w: number;
  h: number;
  /** Degrees, clockwise, about the object's centre. */
  rotation: number;
  /** Paint order within a space. Higher is in front. */
  z: number;
  fill: string;
  stroke: string;
  color: string;
  fontSize: number;
  bold: boolean;
  /** Text content. For frames this is the topic name. */
  text: string;
  /** Image objects only: key into ShiftDocument.assets. */
  assetId?: string;
  /**
   * Containing frame (canvas space only). Containment is declared data, not a
   * geometric accident: moving a frame moves everything whose parentId chain
   * reaches it.
   */
  parentId: string | null;
  /** null = infinite canvas. Otherwise the id of the slide this object lives on. */
  slideId: string | null;
}

/** A slide is a fixed-size page, not a frame. Convert explicitly (see engine). */
export interface Slide {
  id: string;
  name: string;
  width: number;
  height: number;
  notes: string;
}

export type EasingName = 'linear' | 'easeInOut' | 'easeOut';

export type PathTarget =
  | { kind: 'frame'; frameId: string }
  | { kind: 'slide'; slideId: string };

export interface PathStep {
  id: string;
  target: PathTarget;
  /** Camera transition time in milliseconds. 0 = jump cut. */
  duration: number;
  easing: EasingName;
}

export interface PresentationPath {
  id: string;
  name: string;
  steps: PathStep[];
}

/** Metadata only. Binary data lives in the asset store (IndexedDB), not in the document. */
export interface AssetMeta {
  id: string;
  name: string;
  mime: string;
  size: number;
}

export interface Theme {
  name: string;
  accent: string;
  fontFamily: string;
}

export interface ShiftDocument {
  schemaVersion: typeof SCHEMA_VERSION;
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  theme: Theme;
  objects: Record<string, SceneObject>;
  slides: Slide[];
  paths: PresentationPath[];
  activePathId: string | null;
  assets: Record<string, AssetMeta>;
}

export interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}
