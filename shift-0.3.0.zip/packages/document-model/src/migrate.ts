import { createDocument, createObject, createSlide, uid } from './create';
import type { PathStep, SceneObject, ShiftDocument } from './types';

/** Shape of data written by the 0.1/0.2 HTML prototypes (localStorage or .shift.json export). */
export interface PrototypeData {
  format?: string;
  version?: number;
  name?: string;
  objects?: Array<Record<string, unknown>>;
  frames?: Array<{ id?: string; name?: string }>;
  slides?: Array<{ id?: string; name?: string }>;
}

/** An image that must be moved out of the document into the asset store. */
export interface PendingAsset {
  assetId: string;
  name: string;
  dataUrl: string;
}

export interface MigrationResult {
  doc: ShiftDocument;
  assets: PendingAsset[];
  warnings: string[];
}

const num = (v: unknown, d: number) => (typeof v === 'number' && Number.isFinite(v) ? v : d);
const str = (v: unknown, d: string) => (typeof v === 'string' ? v : d);

export function isPrototypeData(v: unknown): v is PrototypeData {
  if (typeof v !== 'object' || v === null) return false;
  const d = v as Record<string, unknown>;
  return Array.isArray(d.objects) && d.schemaVersion === undefined;
}

/**
 * Convert prototype data to a v1 document.
 *
 * Differences from the prototype, all deliberate:
 *  - Frame *objects* are the single source of truth. The prototype's separate
 *    `frames[]` array drifted out of sync when a frame was moved; here it is
 *    used only to order the presentation path.
 *  - Containment is derived once, geometrically, and stored as parentId.
 *  - Images become assets; the document keeps metadata only.
 *  - Known limitation: the prototype stamped every object with a slideId when
 *    the user first visited Slide mode, so such documents migrate with their
 *    content on slide 1 rather than on the canvas.
 */
export function fromPrototype(data: PrototypeData): MigrationResult {
  const warnings: string[] = [];
  const doc = createDocument(str(data.name, 'Imported presentation') || 'Imported presentation');
  const assets: PendingAsset[] = [];

  // Slides
  const slideIdMap = new Map<string, string>();
  (data.slides ?? []).forEach((s, i) => {
    const slide = createSlide(i, str(s.name, `Slide ${i + 1}`));
    if (typeof s.id === 'string') slideIdMap.set(s.id, slide.id);
    doc.slides.push(slide);
  });

  // Objects
  const idMap = new Map<string, string>();
  const frameIdToObj = new Map<string, string>(); // prototype frameId -> new object id
  const converted: SceneObject[] = [];
  (data.objects ?? []).forEach((raw, index) => {
    const type = raw.type;
    if (!['text', 'card', 'rect', 'circle', 'frame', 'image'].includes(String(type))) {
      warnings.push(`Skipped object with unknown type ${String(type)}`);
      return;
    }
    const base = createObject(type as SceneObject['type']);
    const o: SceneObject = {
      ...base,
      id: uid(),
      x: num(raw.x, 0), y: num(raw.y, 0), w: Math.max(1, num(raw.w, base.w)), h: Math.max(1, num(raw.h, base.h)),
      rotation: num(raw.rotation, 0), z: num(raw.z, index),
      fill: str(raw.fill, base.fill), stroke: str(raw.stroke, base.stroke), color: str(raw.color, base.color),
      fontSize: num(raw.fontSize, base.fontSize), bold: raw.bold === true, text: str(raw.text, base.text),
    };
    if (typeof raw.id === 'string') idMap.set(raw.id, o.id);
    const protoSlide = typeof raw.slideId === 'string' ? slideIdMap.get(raw.slideId) : undefined;
    o.slideId = type === 'frame' ? null : protoSlide ?? null;
    if (type === 'frame' && typeof raw.frameId === 'string') frameIdToObj.set(raw.frameId, o.id);
    if (type === 'image') {
      if (typeof raw.src === 'string' && raw.src.startsWith('data:')) {
        const assetId = uid();
        const mime = /^data:([^;,]+)/.exec(raw.src)?.[1] ?? 'image/png';
        assets.push({ assetId, name: `image-${assets.length + 1}`, dataUrl: raw.src });
        doc.assets[assetId] = { id: assetId, name: `image-${assets.length}`, mime, size: Math.round(raw.src.length * 0.75) };
        o.assetId = assetId;
      } else {
        warnings.push('Skipped an image with no embedded data');
        return;
      }
    }
    converted.push(o);
  });
  for (const o of converted) doc.objects[o.id] = o;

  // Containment: smallest frame containing the object's centre (frames: the whole rect).
  const frames = converted.filter((o) => o.type === 'frame');
  for (const o of converted) {
    if (o.slideId !== null) continue;
    let best: SceneObject | null = null;
    for (const f of frames) {
      if (f.id === o.id) continue;
      const inside = o.type === 'frame'
        ? o.x >= f.x && o.y >= f.y && o.x + o.w <= f.x + f.w && o.y + o.h <= f.y + f.h && f.w * f.h > o.w * o.h
        : o.x + o.w / 2 >= f.x && o.x + o.w / 2 <= f.x + f.w && o.y + o.h / 2 >= f.y && o.y + o.h / 2 <= f.y + f.h;
      if (inside && (!best || f.w * f.h < best.w * best.h)) best = f;
    }
    if (best) o.parentId = best.id;
  }

  // Presentation path: order from the prototype's frames[], then any frames not listed.
  const ordered: string[] = [];
  for (const f of data.frames ?? []) {
    const oid = typeof f.id === 'string' ? frameIdToObj.get(f.id) : undefined;
    if (oid && !ordered.includes(oid)) ordered.push(oid);
  }
  for (const f of frames) if (!ordered.includes(f.id)) ordered.push(f.id);
  const steps: PathStep[] = ordered.map((frameId) => ({
    id: uid(), target: { kind: 'frame', frameId }, duration: 900, easing: 'easeInOut',
  }));
  if (steps.length) {
    const pathId = uid();
    doc.paths.push({ id: pathId, name: 'Main path', steps });
    doc.activePathId = pathId;
  }
  return { doc, assets, warnings };
}
