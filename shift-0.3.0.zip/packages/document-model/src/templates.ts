import { createDocument, createObject, createSlide, uid } from './create';
import type { PathStep, SceneObject, ShiftDocument } from './types';

export interface TemplateMeta {
  id: string;
  name: string;
  description: string;
  kind: 'canvas' | 'slides';
}

export const TEMPLATES: readonly TemplateMeta[] = [
  { id: 'blank', name: 'Blank canvas', description: 'Start with an open workspace', kind: 'canvas' },
  { id: 'lesson', name: 'Classroom lesson', description: 'Hook, explanation, examples and recap', kind: 'canvas' },
  { id: 'pitch', name: 'Startup pitch', description: 'Problem, solution, market and ask', kind: 'slides' },
  { id: 'story', name: 'Visual story', description: 'A big-picture narrative with zoomable scenes', kind: 'canvas' },
  { id: 'report', name: 'Project update', description: 'Progress, milestones, risks and next steps', kind: 'slides' },
  { id: 'portfolio', name: 'Creative portfolio', description: 'Introduce work through visual sections', kind: 'canvas' },
];

interface Item { type?: 'text' | 'card'; dx: number; dy: number; text: string; w?: number; h?: number; size?: number; color?: string; fill?: string }

class Builder {
  doc: ShiftDocument;
  steps: PathStep[] = [];
  private z = 0;
  constructor(title: string) { this.doc = createDocument(title); }
  add(o: SceneObject) { o.z = this.z++; this.doc.objects[o.id] = o; return o; }
  frame(name: string, x: number, y: number, items: Item[]) {
    const f = this.add(createObject('frame', { x, y, w: 560, h: 370, text: name }));
    items.forEach((it) => this.add(createObject(it.type ?? 'text', {
      x: x + it.dx, y: y + it.dy, w: it.w ?? 430, h: it.h ?? 75, text: it.text,
      fontSize: it.size ?? 28, color: it.color ?? '#f3f7ff', fill: it.fill ?? 'transparent', parentId: f.id,
    })));
    this.steps.push({ id: uid(), target: { kind: 'frame', frameId: f.id }, duration: 900, easing: 'easeInOut' });
  }
  deck(titles: string[], subs: string[]) {
    titles.forEach((title, i) => {
      const s = createSlide(i, `${i + 1}. ${title}`);
      this.doc.slides.push(s);
      this.add(createObject('text', { x: 60, y: 45, w: 820, h: 80, text: title, fontSize: 38, color: '#17243a', slideId: s.id }));
      this.add(createObject('text', { x: 60, y: 150, w: 800, h: 100, text: subs[i] ?? '', fontSize: 23, color: '#50627c', slideId: s.id }));
      this.add(createObject('rect', { x: 60, y: 280, w: 280, h: 12, fill: '#4b91f1', slideId: s.id }));
    });
  }
  done(): ShiftDocument {
    if (this.steps.length) {
      const id = uid();
      this.doc.paths.push({ id, name: 'Main path', steps: this.steps });
      this.doc.activePathId = id;
    }
    return this.doc;
  }
}

const SUB = '#b8d4f8';

/** Templates are real serialisable documents: objects, frames, paths — not screenshots. */
export function createFromTemplate(id: string): { doc: ShiftDocument; mode: 'canvas' | 'slide' } {
  const meta = TEMPLATES.find((t) => t.id === id) ?? TEMPLATES[0]!;
  const b = new Builder(meta.id === 'blank' ? 'Untitled presentation' : `${meta.name} — Untitled`);
  let mode: 'canvas' | 'slide' = 'canvas';
  switch (meta.id) {
    case 'lesson':
      b.frame('01 · The big question', 80, 70, [
        { dx: 35, dy: 65, text: 'What makes an idea stick?', w: 470, h: 80, size: 37 },
        { dx: 38, dy: 175, text: 'Start with a question students want to answer.', w: 440, h: 70, size: 21, color: SUB }]);
      b.frame('02 · Explore the concept', 760, 70, [
        { dx: 35, dy: 65, text: 'Build the concept', size: 34 },
        { dx: 35, dy: 145, text: 'Explain · Demonstrate · Discuss', size: 22, color: SUB }]);
      b.frame('03 · Check understanding', 1440, 70, [
        { dx: 35, dy: 65, text: 'Can you explain it?', size: 34 },
        { dx: 35, dy: 145, text: 'Try an example. Then explain your reasoning.', size: 21, color: SUB }]);
      break;
    case 'story':
      b.frame('01 · Opening', 60, 80, [
        { dx: 35, dy: 70, text: 'Every great story starts somewhere.', size: 36 },
        { dx: 35, dy: 165, text: 'Set the scene. Introduce the tension.', size: 20, color: SUB }]);
      b.frame('02 · The turning point', 760, 80, [
        { dx: 35, dy: 70, text: 'Then something changes.', size: 36 },
        { dx: 35, dy: 165, text: 'Reveal the unexpected connection.', size: 20, color: SUB }]);
      b.frame('03 · The takeaway', 1460, 80, [
        { dx: 35, dy: 70, text: 'Make the ending matter.', size: 36 },
        { dx: 35, dy: 165, text: 'Leave one clear idea with your audience.', size: 20, color: SUB }]);
      break;
    case 'portfolio':
      b.frame('01 · Introduction', 80, 80, [
        { dx: 35, dy: 65, text: 'Your name / studio', size: 39 },
        { dx: 35, dy: 155, text: 'A short statement about what you make.', size: 20, color: SUB }]);
      b.frame('02 · Selected work', 780, 80, [
        { dx: 35, dy: 65, text: 'Selected work', size: 35 },
        { type: 'card', dx: 35, dy: 135, text: 'Project one', w: 205, h: 145, fill: '#eaf2ff', color: '#17243a', size: 20 },
        { type: 'card', dx: 265, dy: 135, text: 'Project two', w: 205, h: 145, fill: '#eaf2ff', color: '#17243a', size: 20 }]);
      break;
    case 'pitch':
      mode = 'slide';
      b.deck(['The opportunity', 'The problem', 'Our solution', 'Market & model', 'The ask'],
        ['A concise introduction to the opportunity.', 'What is not working today?', 'How will we solve it?', 'Who needs this and how does it scale?', 'What do we need to move forward?']);
      break;
    case 'report':
      mode = 'slide';
      b.deck(['Project overview', 'Progress so far', 'Milestones', 'Risks & blockers', 'Next steps'],
        ['What this update covers.', 'Key achievements and measurable outcomes.', 'What happened and what comes next.', 'What could delay delivery?', 'Owners, actions and target dates.']);
      break;
  }
  return { doc: b.done(), mode };
}
