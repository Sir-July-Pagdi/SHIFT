import { OBJECT_TYPES, SCHEMA_VERSION, type ShiftDocument } from './types';

export type ValidationResult =
  | { ok: true; doc: ShiftDocument }
  | { ok: false; errors: string[] };

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);
const isNum = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const isStr = (v: unknown): v is string => typeof v === 'string';

/**
 * Structural + referential validation. Hand-written on purpose (no schema
 * dependency). Returns every problem found, not just the first.
 */
export function validateDocument(input: unknown): ValidationResult {
  const errors: string[] = [];
  const err = (m: string) => { if (errors.length < 50) errors.push(m); };

  if (!isObj(input)) return { ok: false, errors: ['Document is not an object'] };
  const d = input;
  if (d.schemaVersion !== SCHEMA_VERSION) err(`Unsupported schemaVersion ${String(d.schemaVersion)} (expected ${SCHEMA_VERSION})`);
  if (!isStr(d.id) || !d.id) err('Missing document id');
  if (!isStr(d.title)) err('title must be a string');
  if (!isNum(d.createdAt) || !isNum(d.updatedAt)) err('createdAt/updatedAt must be numbers');
  if (!isObj(d.theme)) err('theme missing');
  if (!isObj(d.objects)) err('objects must be a record');
  if (!Array.isArray(d.slides)) err('slides must be an array');
  if (!Array.isArray(d.paths)) err('paths must be an array');
  if (!isObj(d.assets)) err('assets must be a record');
  if (errors.length) return { ok: false, errors };

  const objects = d.objects as Record<string, Record<string, unknown>>;
  const slides = d.slides as Record<string, unknown>[];
  const paths = d.paths as Record<string, unknown>[];
  const assets = d.assets as Record<string, unknown>;

  const slideIds = new Set<string>();
  slides.forEach((s, i) => {
    if (!isObj(s) || !isStr(s.id)) return err(`slides[${i}] invalid`);
    if (slideIds.has(s.id)) err(`Duplicate slide id ${s.id}`);
    slideIds.add(s.id);
    if (!isStr(s.name) || !isNum(s.width) || !isNum(s.height) || s.width <= 0 || s.height <= 0 || !isStr(s.notes)) err(`slides[${i}] has invalid fields`);
  });

  for (const [key, o] of Object.entries(objects)) {
    if (!isObj(o)) { err(`objects.${key} is not an object`); continue; }
    if (o.id !== key) err(`objects.${key}: id mismatch (${String(o.id)})`);
    if (!OBJECT_TYPES.includes(o.type as never)) err(`objects.${key}: unknown type ${String(o.type)}`);
    for (const f of ['x', 'y', 'w', 'h', 'rotation', 'z', 'fontSize']) if (!isNum(o[f])) err(`objects.${key}.${f} must be a finite number`);
    for (const f of ['fill', 'stroke', 'color', 'text']) if (!isStr(o[f])) err(`objects.${key}.${f} must be a string`);
    if (typeof o.bold !== 'boolean') err(`objects.${key}.bold must be boolean`);
    if (o.slideId !== null && !(isStr(o.slideId) && slideIds.has(o.slideId))) err(`objects.${key}: slideId ${String(o.slideId)} does not exist`);
    if (o.type === 'frame' && o.slideId !== null) err(`objects.${key}: frames live on the canvas only`);
    if (o.type === 'image' && !(isStr(o.assetId) && o.assetId in assets)) err(`objects.${key}: image has no valid assetId`);
    if (o.parentId !== null) {
      const p = isStr(o.parentId) ? objects[o.parentId] : undefined;
      if (!p) err(`objects.${key}: parentId ${String(o.parentId)} does not exist`);
      else if (p.type !== 'frame') err(`objects.${key}: parent ${String(o.parentId)} is not a frame`);
      else if (o.slideId !== null) err(`objects.${key}: slide objects cannot have a parent frame`);
    }
  }
  // parent cycles
  for (const key of Object.keys(objects)) {
    const seen = new Set<string>();
    let cur: string | null = key;
    while (cur) {
      if (seen.has(cur)) { err(`objects.${key}: parent cycle`); break; }
      seen.add(cur);
      const next: unknown = objects[cur]?.parentId;
      cur = isStr(next) ? next : null;
    }
  }

  const pathIds = new Set<string>();
  paths.forEach((p, i) => {
    if (!isObj(p) || !isStr(p.id) || !isStr(p.name) || !Array.isArray(p.steps)) return err(`paths[${i}] invalid`);
    pathIds.add(p.id);
    (p.steps as Record<string, unknown>[]).forEach((s, j) => {
      const at = `paths[${i}].steps[${j}]`;
      if (!isObj(s) || !isStr(s.id) || !isObj(s.target)) return err(`${at} invalid`);
      if (!isNum(s.duration) || s.duration < 0) err(`${at}.duration invalid`);
      if (!['linear', 'easeInOut', 'easeOut'].includes(String(s.easing))) err(`${at}.easing invalid`);
      const t = s.target as Record<string, unknown>;
      if (t.kind === 'frame') {
        const f = isStr(t.frameId) ? objects[t.frameId] : undefined;
        if (!f || f.type !== 'frame') err(`${at} targets missing frame ${String(t.frameId)}`);
      } else if (t.kind === 'slide') {
        if (!(isStr(t.slideId) && slideIds.has(t.slideId))) err(`${at} targets missing slide ${String(t.slideId)}`);
      } else err(`${at} has unknown target kind`);
    });
  });
  if (d.activePathId !== null && !(isStr(d.activePathId) && pathIds.has(d.activePathId))) err('activePathId does not exist');

  return errors.length ? { ok: false, errors } : { ok: true, doc: input as unknown as ShiftDocument };
}

export function serialize(doc: ShiftDocument): string {
  return JSON.stringify(doc);
}

export function parseDocument(json: string): ValidationResult {
  try { return validateDocument(JSON.parse(json)); }
  catch (e) { return { ok: false, errors: [`Invalid JSON: ${(e as Error).message}`] }; }
}
