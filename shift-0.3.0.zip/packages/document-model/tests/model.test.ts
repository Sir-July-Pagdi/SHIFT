import { describe, expect, it } from 'vitest';
import {
  TEMPLATES, createDocument, createFromTemplate, createObject, fromPrototype, parseDocument,
  serialize, validateDocument,
} from '../src';

describe('validateDocument', () => {
  it('accepts a fresh document', () => {
    expect(validateDocument(createDocument()).ok).toBe(true);
  });

  it('round-trips through JSON unchanged', () => {
    const { doc } = createFromTemplate('lesson');
    const r = parseDocument(serialize(doc));
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.doc).toEqual(doc);
  });

  it('reports referential problems', () => {
    const doc = createDocument();
    const o = createObject('rect', { parentId: 'nope', slideId: 'ghost' });
    doc.objects[o.id] = o;
    const r = validateDocument(doc);
    expect(r.ok).toBe(false);
    if (!r.ok) {
      expect(r.errors.join('\n')).toMatch(/parentId nope does not exist/);
      expect(r.errors.join('\n')).toMatch(/slideId ghost does not exist/);
    }
  });

  it('rejects non-finite numbers, wrong versions and image without asset', () => {
    const doc = createDocument();
    const o = createObject('image');
    doc.objects[o.id] = o;
    expect(validateDocument(doc).ok).toBe(false);
    const bad = createDocument();
    const r = createObject('rect', { x: NaN });
    bad.objects[r.id] = r;
    expect(validateDocument(bad).ok).toBe(false);
    expect(validateDocument({ ...createDocument(), schemaVersion: 99 }).ok).toBe(false);
    expect(validateDocument(null).ok).toBe(false);
  });

  it('detects parent cycles', () => {
    const doc = createDocument();
    const a = createObject('frame');
    const b = createObject('frame');
    a.parentId = b.id; b.parentId = a.id;
    doc.objects[a.id] = a; doc.objects[b.id] = b;
    const r = validateDocument(doc);
    expect(r.ok).toBe(false);
  });
});

describe('templates', () => {
  it.each(TEMPLATES.map((t) => t.id))('%s produces a valid document', (id) => {
    const { doc, mode } = createFromTemplate(id);
    const r = validateDocument(doc);
    expect(r.ok, r.ok ? '' : r.errors.join('; ')).toBe(true);
    if (id === 'pitch' || id === 'report') {
      expect(mode).toBe('slide');
      expect(doc.slides).toHaveLength(5);
    } else if (id !== 'blank') {
      expect(doc.paths[0]!.steps.length).toBeGreaterThanOrEqual(2);
    }
  });

  it('frame children are parented to their frame', () => {
    const { doc } = createFromTemplate('story');
    const frames = Object.values(doc.objects).filter((o) => o.type === 'frame');
    expect(frames).toHaveLength(3);
    const texts = Object.values(doc.objects).filter((o) => o.type === 'text');
    expect(texts.every((t) => t.parentId !== null)).toBe(true);
  });
});

describe('fromPrototype', () => {
  const png = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  const proto = {
    name: 'Old deck',
    frames: [{ id: 'f2', name: 'B' }, { id: 'f1', name: 'A' }],
    slides: [{ id: 's1', name: 'Slide 1' }],
    objects: [
      { id: 'fo1', type: 'frame', frameId: 'f1', x: 0, y: 0, w: 500, h: 300, text: 'A', z: -1, slideId: 's1' },
      { id: 'fo2', type: 'frame', frameId: 'f2', x: 800, y: 0, w: 500, h: 300, text: 'B', z: -1 },
      { id: 't1', type: 'text', x: 40, y: 40, w: 200, h: 60, text: 'inside A', z: 1 },
      { id: 't2', type: 'text', x: 900, y: 40, w: 200, h: 60, text: 'inside B', z: 2 },
      { id: 't3', type: 'text', x: 3000, y: 3000, w: 200, h: 60, text: 'free', z: 3 },
      { id: 'sl', type: 'rect', x: 10, y: 10, w: 50, h: 50, z: 4, slideId: 's1' },
      { id: 'img', type: 'image', x: 0, y: 0, w: 10, h: 10, src: png, z: 5 },
      { id: 'weird', type: 'hexagon' },
    ],
  };

  it('produces a valid v1 document', () => {
    const { doc, warnings } = fromPrototype(proto);
    const r = validateDocument(doc);
    expect(r.ok, r.ok ? '' : r.errors.join('; ')).toBe(true);
    expect(warnings.join()).toMatch(/unknown type hexagon/);
  });

  it('uses frame objects as truth, derives parents, orders the path from frames[]', () => {
    const { doc } = fromPrototype(proto);
    const byText = (t: string) => Object.values(doc.objects).find((o) => o.text === t)!;
    const frameA = byText('A');
    const frameB = byText('B');
    expect(byText('inside A').parentId).toBe(frameA.id);
    expect(byText('inside B').parentId).toBe(frameB.id);
    expect(byText('free').parentId).toBeNull();
    expect(frameA.slideId).toBeNull(); // prototype stamped slideId on frames; we do not keep it
    const order = doc.paths[0]!.steps.map((s) => (s.target.kind === 'frame' ? doc.objects[s.target.frameId]!.text : ''));
    expect(order).toEqual(['B', 'A']);
  });

  it('moves images into pending assets', () => {
    const { doc, assets } = fromPrototype(proto);
    expect(assets).toHaveLength(1);
    const img = Object.values(doc.objects).find((o) => o.type === 'image')!;
    expect(img.assetId).toBe(assets[0]!.assetId);
    expect(doc.assets[img.assetId!]!.mime).toBe('image/png');
    expect(JSON.stringify(doc)).not.toContain('base64');
  });
});
