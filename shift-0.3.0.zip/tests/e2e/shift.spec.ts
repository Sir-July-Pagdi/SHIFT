import { expect, test, type Locator, type Page } from '@playwright/test';
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');

type Obj = { id: string; type: string; x: number; y: number; w: number; h: number; rot: number; text: string };

test.beforeEach(async ({ page }) => {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  (page as Page & { _errors: string[] })._errors = errors;
  await page.goto('/');
  await expect(page.getByTestId('stage')).toBeVisible();
});
test.afterEach(async ({ page }) => {
  expect((page as Page & { _errors: string[] })._errors, 'no uncaught page errors').toEqual([]);
});

const objs = (page: Page): Promise<Obj[]> =>
  page.$$eval('[data-testid=world] .obj', (els) => els.map((e) => {
    const s = (e as HTMLElement).style;
    return {
      id: (e as HTMLElement).dataset.id!, type: (e as HTMLElement).dataset.type!, x: parseFloat(s.left), y: parseFloat(s.top),
      w: parseFloat(s.width), h: parseFloat(s.height), rot: parseFloat((s.transform.match(/rotate\(([-\d.]+)deg\)/) ?? [0, '0'])[1]!), text: (e as HTMLElement).textContent ?? '',
    };
  }));
const byType = async (page: Page, t: string) => (await objs(page)).filter((o) => o.type === t);
const ribbon = (page: Page, id: string) => page.locator(`[data-ribbon=${id}]`);
const tab = (page: Page, name: string) => page.getByRole('tab', { name, exact: true }).click();
const saved = (page: Page) => expect(page.getByTestId('save-status')).toHaveAttribute('data-status', 'saved');

async function drag(page: Page, from: { x: number; y: number }, dx: number, dy: number) {
  await page.mouse.move(from.x, from.y);
  await page.mouse.down();
  await page.mouse.move(from.x + dx / 2, from.y + dy / 2, { steps: 4 });
  await page.mouse.move(from.x + dx, from.y + dy, { steps: 4 });
  await page.mouse.up();
}
const center = async (l: Locator) => { const b = (await l.boundingBox())!; return { x: b.x + b.width / 2, y: b.y + b.height / 2 }; };
const obj = (page: Page, id: string) => page.locator(`[data-testid=world] .obj[data-id="${id}"]`);
const worldTransform = (page: Page, tid = 'world') => page.getByTestId(tid).evaluate((e) => (e as HTMLElement).style.transform);
const template = async (page: Page, id: string) => { await page.locator('#templatesBtn').click(); await page.locator(`[data-template=${id}]`).click(); };

test('boots with a starter presentation: frame, contents, path step, no errors', async ({ page }) => {
  const o = await objs(page);
  expect(o.map((x) => x.type).sort()).toEqual(['card', 'circle', 'frame', 'text']);
  await expect(page.getByTestId('step-list').locator('.thumb')).toHaveCount(1);
  await expect(page.getByTestId('layer-count')).toHaveText('4');
  await saved(page);
});

test('every Home/Insert button does what it says', async ({ page }) => {
  const n0 = (await objs(page)).length;
  for (const [id, type] of [['rect', 'rect'], ['circle', 'circle'], ['card', 'card']] as const) {
    await ribbon(page, id).click();
    expect((await byType(page, type)).length).toBeGreaterThan(0);
  }
  await ribbon(page, 'frame').click();
  expect((await byType(page, 'frame')).length).toBe(2);
  await ribbon(page, 'text').click();
  await expect(page.locator('.inline-editor')).toBeVisible(); // adding text opens the editor immediately
  await page.keyboard.type('Hello Shift');
  await page.locator('.inline-editor').blur();
  await expect(page.locator('[data-testid=world] .obj.text', { hasText: 'Hello Shift' })).toHaveCount(1);
  expect((await objs(page)).length).toBe(n0 + 5);
  await expect(page.getByTestId('layer-count')).toHaveText(String(n0 + 5)); // layers panel stays in sync
  await expect(page.getByTestId('step-list').locator('.thumb')).toHaveCount(2);
  // tabs switch and show distinct tools
  for (const t of ['Insert', 'Design', 'Arrange', 'Animate', 'Present', 'View', 'Home']) {
    await tab(page, t);
    await expect(page.getByTestId('ribbon')).toHaveAttribute('data-tab', t);
  }
  // image
  await page.getByTestId('image-input').setInputFiles({ name: 'dot.png', mimeType: 'image/png', buffer: PNG });
  await expect.poll(async () => (await byType(page, 'image')).length).toBe(1);
  await expect(page.locator('[data-testid=world] .obj.image img')).toBeVisible();
});

test('drag moves one object and is a single undo step; undo/redo buttons reflect state', async ({ page }) => {
  const circle = (await byType(page, 'circle'))[0]!;
  await expect(page.locator('#undoBtn')).toBeDisabled();
  await drag(page, await center(obj(page, circle.id)), 90, 40);
  const moved = (await byType(page, 'circle'))[0]!;
  expect(moved.x).toBeGreaterThan(circle.x + 20);
  await expect(page.locator('#undoBtn')).toBeEnabled();
  await page.locator('#undoBtn').click();
  expect((await byType(page, 'circle'))[0]!.x).toBeCloseTo(circle.x, 1);
  await expect(page.locator('#undoBtn')).toBeDisabled(); // one gesture == one undo step
  await page.locator('#redoBtn').click();
  expect((await byType(page, 'circle'))[0]!.x).toBeCloseTo(moved.x, 1);
  await page.keyboard.press('Control+z');
  expect((await byType(page, 'circle'))[0]!.x).toBeCloseTo(circle.x, 1);
});

test('frames contain things: moving a frame carries children; dragging a child out detaches it', async ({ page }) => {
  const frame = (await byType(page, 'frame'))[0]!;
  const before = await objs(page);
  const fb = (await obj(page, frame.id).boundingBox())!;
  await drag(page, { x: fb.x + fb.width - 14, y: fb.y + fb.height - 14 }, 60, 50);
  const after = await objs(page);
  for (const b of before) {
    const a = after.find((x) => x.id === b.id)!;
    expect(a.x - b.x, `${b.type} moved with frame`).toBeGreaterThan(10);
  }
  // pull the circle far outside the frame
  const circle = (await byType(page, 'circle'))[0]!;
  const c0 = circle.x;
  await drag(page, await center(obj(page, circle.id)), 10, 10);
  const frameAfter = (await byType(page, 'frame'))[0]!;
  await drag(page, await center(obj(page, circle.id)), 0, 0);
  // now move the frame again: circle (still inside) follows
  const fb2 = (await obj(page, frame.id).boundingBox())!;
  await drag(page, { x: fb2.x + fb2.width - 14, y: fb2.y + fb2.height - 14 }, -30, 0);
  const circleNow = (await byType(page, 'circle'))[0]!;
  expect(circleNow.x).toBeLessThan(c0 + 70); // moved left with the frame
  expect(frameAfter.id).toBe(frame.id);
});

test('resize and rotate handles work, and the inspector updates', async ({ page }) => {
  await ribbon(page, 'rect').click();
  const r0 = (await byType(page, 'rect'))[0]!;
  const se = page.locator('.handle-se');
  await expect(se).toBeVisible();
  await drag(page, await center(se), 70, 50);
  const r1 = (await byType(page, 'rect'))[0]!;
  expect(r1.w).toBeGreaterThan(r0.w + 10);
  expect(r1.h).toBeGreaterThan(r0.h + 5);
  expect(r1.x).toBeCloseTo(r0.x, 0); // the opposite (top-left) corner stays put
  await expect(page.locator('#properties [data-k=w]')).toHaveValue(String(Math.round(r1.w * 10) / 10));
  const rot = page.locator('.handle-rotate');
  const rc = await center(obj(page, r1.id));
  const rh = await center(rot);
  await drag(page, rh, rc.x + 200 - rh.x, rc.y - rh.y); // swing the handle to the right of the centre
  const r2 = (await byType(page, 'rect'))[0]!;
  expect(r2.rot).toBeGreaterThan(60);
  expect(r2.rot).toBeLessThan(120);
  // numeric rotation field
  await page.locator('#properties [data-k=rotation]').fill('30');
  await page.locator('#properties [data-k=rotation]').press('Enter');
  expect((await byType(page, 'rect'))[0]!.rot).toBe(30);
});

test('double-click edits text in place; Backspace in a field does not delete the object', async ({ page }) => {
  const t = (await byType(page, 'text'))[0]!;
  await obj(page, t.id).dblclick();
  await page.locator('.inline-editor').fill('Edited in place');
  await page.locator('.inline-editor').blur();
  await expect(obj(page, t.id)).toHaveText('Edited in place');
  const n = (await objs(page)).length;
  await page.locator('#properties [data-k=x]').focus();
  await page.keyboard.press('Backspace');
  expect((await objs(page)).length).toBe(n);
  await page.locator('#docname').fill('My deck');
  await page.locator('#docname').press('Backspace');
  await expect(page.locator('#docname')).toHaveValue('My dec');
  await page.locator('#docname').blur();
  // keyboard delete / duplicate on a selection
  await obj(page, t.id).click();
  await page.keyboard.press('Control+d');
  expect((await objs(page)).length).toBe(n + 1);
  await page.keyboard.press('Delete');
  expect((await objs(page)).length).toBe(n);
});

test('templates: all six load as real editable objects with paths/slides', async ({ page }) => {
  for (const id of ['lesson', 'story', 'portfolio', 'pitch', 'report', 'blank']) {
    await template(page, id);
    const o = await objs(page);
    if (id === 'blank') expect(o).toHaveLength(0);
    else if (id === 'pitch' || id === 'report') expect(o).toHaveLength(3); // slide 1 only
    else expect(o.length).toBeGreaterThanOrEqual(7);
    if (id === 'pitch' || id === 'report') {
      await expect(page.getByTestId('slide-list').locator('.thumb')).toHaveCount(5);
      const text = o.find((x) => x.type === 'text')!;
      await obj(page, text.id).dblclick(); // editable, not a screenshot
      await expect(page.locator('.inline-editor')).toBeVisible();
      await page.keyboard.press('Escape');
    }
  }
  // template load is undoable
  await template(page, 'lesson');
  await page.locator('#undoBtn').click();
  expect(await objs(page)).toHaveLength(0);
});

test('presenting a path: camera really moves between frames, keys navigate, Escape exits', async ({ page }) => {
  await template(page, 'lesson');
  await page.locator('#presentBtn').click();
  await expect(page.getByTestId('presenter')).toBeVisible();
  await expect(page.getByTestId('step-label')).toHaveText('1 / 3');
  const t0 = await worldTransform(page, 'present-world');
  await page.keyboard.press('ArrowRight');
  await page.waitForTimeout(350);
  const mid = await worldTransform(page, 'present-world');
  await page.waitForTimeout(1200);
  const t1 = await worldTransform(page, 'present-world');
  expect(mid).not.toBe(t0);
  expect(mid).not.toBe(t1); // a tween in flight, not a jump cut
  expect(t1).not.toBe(t0);
  await expect(page.getByTestId('step-label')).toHaveText('2 / 3');
  await page.keyboard.press('End');
  await expect(page.getByTestId('step-label')).toHaveText('3 / 3');
  await page.keyboard.press('ArrowLeft');
  await expect(page.getByTestId('step-label')).toHaveText('2 / 3');
  await page.getByRole('button', { name: 'Exit presentation' }).click();
  await expect(page.getByTestId('presenter')).toHaveCount(0);
});

test('reduced motion makes camera moves instant', async ({ page }) => {
  await template(page, 'lesson');
  await tab(page, 'View');
  await ribbon(page, 'reduced').click();
  await page.locator('#presentBtn').click();
  const t0 = await worldTransform(page, 'present-world');
  await page.keyboard.press('ArrowRight');
  await page.waitForTimeout(60);
  const t1 = await worldTransform(page, 'present-world');
  await page.waitForTimeout(500);
  expect(await worldTransform(page, 'present-world')).toBe(t1);
  expect(t1).not.toBe(t0);
});

test('path editing: reorder steps, edit transition, multiple paths', async ({ page }) => {
  await template(page, 'lesson');
  const labels = () => page.getByTestId('step-list').locator('.thumb-title').allTextContents();
  const first = (await labels())[0]!;
  await page.getByRole('button', { name: 'Move step down' }).first().click();
  expect((await labels())[1]).toBe(first.replace(/^\d+\./, '2.'));
  await page.getByTestId('step-list').locator('.thumb').first().click();
  await tab(page, 'Animate');
  await page.getByTestId('step-editor').locator('input[type=number]').fill('1500');
  await page.getByTestId('step-editor').locator('select').selectOption('linear');
  await expect(page.getByTestId('step-editor').locator('input[type=number]')).toHaveValue('1500');
  await page.getByRole('button', { name: '＋ Path' }).click();
  await expect(page.getByLabel('Active path')).toHaveValue(/.+/);
  expect(await page.getByLabel('Active path').locator('option').count()).toBe(2);
  await page.getByRole('button', { name: 'Remove step' }).first().click();
  await expect(page.getByTestId('step-list').locator('.thumb')).toHaveCount(2);
  await page.getByLabel('Active path').selectOption({ index: 0 });
  await expect(page.getByTestId('step-list').locator('.thumb')).toHaveCount(3); // the other path is untouched
});

test('slide mode: add/reorder/duplicate/delete slides, notes, present slides, frame<->slide', async ({ page }) => {
  await template(page, 'blank');
  await page.locator('#slideMode').click();
  await expect(page.getByTestId('slide-list').locator('.thumb')).toHaveCount(1);
  await ribbon(page, 'text').click();
  await page.keyboard.type('Slide one');
  await page.locator('.inline-editor').blur();
  const tx = (await byType(page, 'text'))[0]!;
  const color = await obj(page, tx.id).evaluate((e) => getComputedStyle(e).color);
  expect(color).toBe('rgb(23, 36, 58)'); // dark text on white paper
  await page.getByRole('button', { name: 'Add slide' }).click();
  await ribbon(page, 'card').click();
  await expect(page.getByTestId('slide-list').locator('.thumb')).toHaveCount(2);
  expect(await objs(page)).toHaveLength(1); // slide 2 shows only its own objects
  await page.getByRole('button', { name: 'Move slide up' }).nth(1).click();
  await page.getByRole('button', { name: 'Duplicate slide' }).first().click();
  await expect(page.getByTestId('slide-list').locator('.thumb')).toHaveCount(3);
  await page.keyboard.press('Escape');
  await page.getByTestId('notes').fill('Remember the story');
  await page.locator('#presentBtn').click();
  await expect(page.getByTestId('presenter')).toBeVisible();
  await page.getByRole('button', { name: 'Toggle notes' }).click();
  await expect(page.getByTestId('present-notes')).toBeVisible();
  await page.keyboard.press('Escape');
  await page.getByRole('button', { name: 'Delete slide' }).last().click();
  await expect(page.getByTestId('slide-list').locator('.thumb')).toHaveCount(2);
  // slide -> frame on canvas
  await tab(page, 'Arrange');
  await ribbon(page, 'slide-to-frame').click();
  await page.locator('#canvasMode').click();
  await expect.poll(async () => (await byType(page, 'frame')).length).toBe(1);
  await expect(page.getByTestId('step-list').locator('.thumb')).toHaveCount(1);
  // frame -> slide
  await page.locator('.layer:has(.dot.frame)').first().click(); // the new frame may be off-screen; select it from the layers panel
  await ribbon(page, 'frame-to-slide').click();
  await page.locator('#slideMode').click();
  await expect(page.getByTestId('slide-list').locator('.thumb')).toHaveCount(3);
});

test('autosave persists across reload; 120 objects survive intact', async ({ page }) => {
  await template(page, 'blank');
  for (let i = 0; i < 40; i++) {
    await ribbon(page, 'rect').click();
    await ribbon(page, 'circle').click();
    await ribbon(page, 'card').click();
  }
  expect(await objs(page)).toHaveLength(120);
  await page.locator('#docname').fill('Hundred twenty');
  await saved(page);
  await page.reload();
  await expect(page.getByTestId('stage')).toBeVisible();
  expect(await objs(page)).toHaveLength(120);
  await expect(page.locator('#docname')).toHaveValue('Hundred twenty');
  await expect(page.getByTestId('layer-count')).toHaveText('120');
});

test('documents: create, switch, delete; export then import round-trips with images', async ({ page }, info) => {
  await page.getByTestId('image-input').setInputFiles({ name: 'dot.png', mimeType: 'image/png', buffer: PNG });
  await expect.poll(async () => (await byType(page, 'image')).length).toBe(1);
  await page.locator('#docname').fill('Original');
  await saved(page);
  await page.locator('#menuBtn').click();
  const [dl] = await Promise.all([page.waitForEvent('download'), page.locator('[data-drawer=export]').click()]);
  const file = join(tmpdir(), `shift-${info.workerIndex}.shift.json`);
  await dl.saveAs(file);
  const bundle = JSON.parse(readFileSync(file, 'utf8'));
  expect(bundle.format).toBe('shift-bundle');
  expect(Object.keys(bundle.assets)).toHaveLength(1);
  // new doc, then import the backup as another doc
  await page.locator('#menuBtn').click();
  await page.locator('[data-drawer=new]').click();
  await expect.poll(async () => (await objs(page)).length).toBe(0);
  await page.locator('#menuBtn').click();
  await page.getByTestId('drawer-import').setInputFiles(file);
  await expect.poll(async () => (await byType(page, 'image')).length).toBe(1);
  await expect(page.locator('[data-testid=world] .obj.image img')).toBeVisible();
  // documents dialog lists both, can switch and delete
  await page.locator('#menuBtn').click();
  await page.locator('[data-drawer=open]').click();
  await expect(page.locator('.doc-row')).toHaveCount(3);
  await page.locator('.doc-row', { hasText: 'Untitled presentation' }).first().locator('.doc-open').click();
  await page.locator('#menuBtn').click();
  await page.locator('[data-drawer=open]').click();
  await page.locator('.doc-row').last().getByRole('button', { name: /Delete/ }).click();
  await page.getByRole('button', { name: 'Really delete' }).click();
  await expect(page.locator('.doc-row')).toHaveCount(2);
});

test('imports a Shift 0.2 prototype file', async ({ page }) => {
  const proto = {
    name: 'From prototype', frames: [{ id: 'f1', name: 'A' }], slides: [],
    objects: [
      { id: 'fo', type: 'frame', frameId: 'f1', x: 0, y: 0, w: 500, h: 300, text: 'Topic A', z: -1 },
      { id: 't', type: 'text', x: 40, y: 40, w: 300, h: 60, text: 'inside', z: 1 },
    ],
  };
  const f = join(tmpdir(), 'proto.json');
  writeFileSync(f, JSON.stringify(proto));
  await page.locator('#menuBtn').click();
  await page.getByTestId('drawer-import').setInputFiles(f);
  await expect(page.locator('#docname')).toHaveValue('From prototype');
  expect(await objs(page)).toHaveLength(2);
  await expect(page.getByTestId('step-list').locator('.thumb')).toHaveCount(1);
  const [frame, text] = [(await byType(page, 'frame'))[0]!, (await byType(page, 'text'))[0]!];
  const fb = (await obj(page, frame.id).boundingBox())!;
  await drag(page, { x: fb.x + fb.width - 14, y: fb.y + fb.height - 14 }, 50, 0);
  expect((await byType(page, 'text'))[0]!.x).toBeGreaterThan(text.x + 5); // migrated containment works
});

test('recovery: a newer snapshot than the saved document is offered and restorable', async ({ page }) => {
  await page.locator('#docname').fill('Saved version');
  await saved(page);
  await page.evaluate(() => new Promise<void>((resolve, reject) => {
    const open = indexedDB.open('shift');
    open.onerror = () => reject(open.error);
    open.onsuccess = () => {
      const db = open.result;
      const tx = db.transaction(['documents', 'snapshots'], 'readwrite');
      tx.objectStore('documents').getAll().onsuccess = (ev) => {
        const row = (ev.target as IDBRequest).result[0];
        const doc = { ...row.doc, title: 'Unsaved newer version', updatedAt: row.doc.updatedAt + 60_000 };
        tx.objectStore('snapshots').add({ docId: row.id, takenAt: Date.now(), docUpdatedAt: doc.updatedAt, doc });
      };
      tx.oncomplete = () => { db.close(); resolve(); };
      tx.onerror = () => reject(tx.error);
    };
  }));
  await page.reload();
  await expect(page.getByTestId('recovery-banner')).toBeVisible();
  await expect(page.locator('#docname')).toHaveValue('Saved version');
  await page.getByRole('button', { name: 'Recover it' }).click();
  await expect(page.locator('#docname')).toHaveValue('Unsaved newer version');
  await saved(page);
  await page.reload();
  await expect(page.locator('#docname')).toHaveValue('Unsaved newer version');
  await expect(page.getByTestId('recovery-banner')).toHaveCount(0);
});

test('works fully offline: reload with the network off still opens the app and the saved document', async ({ page, context }) => {
  await page.locator('#docname').fill('Offline proof');
  await saved(page);
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.reload(); // let the service worker take control
  await expect.poll(() => page.evaluate(() => !!navigator.serviceWorker.controller)).toBe(true);
  await context.setOffline(true);
  await page.reload();
  await expect(page.getByTestId('stage')).toBeVisible();
  await expect(page.locator('#docname')).toHaveValue('Offline proof');
  await ribbon(page, 'rect').click();
  await saved(page);
  expect((await byType(page, 'rect')).length).toBe(1);
  await page.locator('#presentBtn').click();
  await expect(page.getByTestId('presenter')).toBeVisible();
  await context.setOffline(false);
});

test('tablet/phone layout: panels collapse into drawers and stay reachable', async ({ page }) => {
  await page.setViewportSize({ width: 820, height: 1100 });
  await expect(page.getByTestId('left-panel')).not.toBeInViewport();
  await page.getByRole('button', { name: '▤ Pages' }).click();
  await expect(page.getByTestId('left-panel')).toBeInViewport();
  await expect(page.getByTestId('step-list')).toBeVisible();
  await page.locator('.panel-back').click({ position: { x: 790, y: 500 } });
  await page.getByRole('button', { name: '⚙ Inspector' }).click();
  await expect(page.getByTestId('inspector')).toBeInViewport();
  await page.locator('.panel-back').click({ position: { x: 10, y: 500 } });
  await page.setViewportSize({ width: 390, height: 800 });
  await expect(page.getByRole('button', { name: '▶ Present' })).toBeVisible();
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth);
  expect(overflow).toBe(false);
});

test('touch: tap selects, one-finger drag on empty canvas pans, two-finger pinch zooms', async ({ browser }) => {
  const ctx = await browser.newContext({ hasTouch: true, viewport: { width: 1024, height: 768 } });
  const page = await ctx.newPage();
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto('/');
  await expect(page.getByTestId('stage')).toBeVisible();
  const cdp = await ctx.newCDPSession(page);
  const touch = (type: string, pts: Array<{ x: number; y: number }>) =>
    cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((p, i) => ({ x: p.x, y: p.y, id: i })) });
  const stage = (await page.getByTestId('stage').boundingBox())!;
  const t0 = await worldTransform(page);
  // pan on empty area (top-right corner of the stage is empty)
  const a = { x: stage.x + stage.width - 80, y: stage.y + 60 };
  await touch('touchStart', [a]); await touch('touchMove', [{ x: a.x - 60, y: a.y + 40 }]); await touch('touchEnd', []);
  const t1 = await worldTransform(page);
  expect(t1).not.toBe(t0);
  // pinch out
  const c = { x: stage.x + stage.width / 2, y: stage.y + stage.height / 2 };
  const z0 = await page.getByTestId('zoom-label').textContent();
  await touch('touchStart', [{ x: c.x - 40, y: c.y }, { x: c.x + 40, y: c.y }]);
  await touch('touchMove', [{ x: c.x - 120, y: c.y }, { x: c.x + 120, y: c.y }]);
  await touch('touchEnd', []);
  expect(await page.getByTestId('zoom-label').textContent()).not.toBe(z0);
  expect(errors).toEqual([]);
  await ctx.close();
});

test('a fly-to animation never overwrites a later camera change (template load mid-flight)', async ({ page }) => {
  await page.goto('/?debug');
  await expect(page.getByTestId('stage')).toBeVisible();
  await template(page, 'lesson');
  await page.getByTestId('step-list').locator('.thumb').nth(1).click(); // starts a ~450ms camera animation
  await template(page, 'pitch'); // switches to slide mode and refits immediately
  await page.waitForTimeout(800);
  const cam = await page.evaluate(() => (window as unknown as { __shift: { getState: () => { camera: { x: number; zoom: number }; viewport: { width: number } } } }).__shift.getState());
  expect(cam.camera.x).toBeCloseTo(480, 0); // centred on the 960-wide slide
  expect(cam.camera.zoom).toBeLessThan((cam.viewport.width - 20) / 960 + 0.01); // the whole slide fits
});
