# Architecture review — Shift Architecture v1.0

Reviewed against what was actually built and tested in 0.3. Items are marked
**Verified** (an automated test exercises it), **Implemented, unverified**
(code exists, no test proves it), or **Not done**.

Note: the architecture document supplied ended mid-sentence in §11 ("Initial
development rel…"). The consolidated spec at the end was not available; this
review covers §1–§10.

## Decisions that held up

| Decision | Result |
|---|---|
| One engine, two editing modes | Held. Slides and canvas share one `SceneObject` type, one validator, one renderer (`SceneView`), one asset store. Verified by frame↔slide round-trip tests. |
| Frame ≠ slide | Held, and it forced a real design: conversion is an explicit, lossy operation (`frameToSlide`, `slideToFrame`). |
| Document model independent of the renderer | Held. `@shift/document-model` has no dependencies at all. Verified: it round-trips through JSON unchanged (test). |
| Camera engine independent of the renderer | Held. Pure maths; the DOM renderer only applies one CSS transform string. Verified: world↔screen inverses, zoom-about-cursor, geometric zoom interpolation. |
| Multiple paths through one document | Held and useful (e.g. a different order per class). Verified. |
| Local-first, IndexedDB + Dexie | Held. Verified: reload persistence, 120 objects, export/import with images, simulated interrupted-save recovery. |
| PWA via Workbox | Held. Verified: with the network switched off, a reload still opens the app and the saved document. |

## Deliberate deviations from the spec

| Spec | What was built | Why |
|---|---|---|
| Konva for rendering | DOM renderer behind `SceneView` | Konva's main value is hit-testing and transform handles; those cost ~120 lines here (`geometry.ts`, `Viewport.tsx`) and are unit-tested. DOM gives crisp text, native text editing and accessibility for free, which the spec itself says needs DOM overlays anyway. **Not benchmarked beyond 120 objects.** Revisit if profiling shows trouble past ~1–2k objects. `SceneView` is the single seam to replace. |
| GSAP | 15-line camera tween (`cameraAt` + rAF) | Camera moves need only interpolation + easing. GSAP becomes worthwhile for per-object animation timelines, which are not built yet. Check its current licence terms before adopting. |
| Tailwind | Hand-written CSS ported from the 0.2 prototype | Preserves the established visual direction; adds no dependency. |
| 10 engine packages | 2 packages (`document-model`, `engine`) | The spec itself warns against over-engineering. Split `engine` when a module gains its own dependencies or a second consumer. Module boundaries inside it already match the spec (`camera`, `history`, `scene`, `paths`, `slides`, `geometry`). |
| `CameraState.duration` | Duration and easing live on `PathStep` | A camera *state* is a place; a *transition* is a property of arriving there. Keeps interpolation a pure function of two states. |
| `syncQueue`, `recentFiles` stores | Omitted | No cloud yet; "recent" is documents ordered by `updatedAt`. Add `syncQueue` with the first sync feature. |
| `.shift` ZIP package | `.shift.json` bundle (document + assets as data URLs) | Avoids a ZIP dependency for now. Format is versioned (`bundleVersion`, `schemaVersion`). |
| OPFS | Not used | Blobs in IndexedDB are fine at this scale; add OPFS only if large-media tests demand it. |

## Gaps and risks in the architecture itself

1. **Grouping is listed in the MVP but conflicts in spirit with frames.** Frames
   give containment today. A true multi-object group (select several, move/scale
   as one, no visible border) is not built. Decide whether groups are a separate
   object type or a frame variant before building it.
2. **Rich text is MVP-listed but unspecified.** Text is plain with one
   size/colour/weight per object. Rich text needs a document-model decision
   (spans? ProseMirror/Lexical JSON?) *before* more templates are written, or
   migration pain follows.
3. **Whole-document writes.** Each autosave `put`s the full document. Fine now;
   will become the bottleneck on very large decks. Mitigation path: store
   objects as rows and write diffs. The history engine already shares structure
   between snapshots, so this is a storage-layer change only.
4. **Browser storage is not guaranteed.** `navigator.storage.persist()` is
   requested and the status bar says whether it was granted, but browsers may
   refuse or evict. Export backups are the real safety net; consider a periodic
   backup reminder.
5. **Mixed paths are modelled but not exposed.** A path step can target a frame
   or a slide, so one story can zoom around a canvas and then land on a slide.
   The UI only creates frame steps; slides use an implicit ordered path. The
   presenter switches space without a camera tween when the space changes.
6. **Slide layouts, themes and placeholders** (spec §1B) are not built. Slides
   are free-form pages at a configurable size.
7. **Camera rotation** exists in the maths and the CSS but there is no UI for
   it, and handles/hit-testing under camera rotation are untested.
8. **Accessibility.** Keyboard operation covers delete, duplicate, nudge, undo,
   select-all, and presenter navigation. Canvas objects have no ARIA roles or
   focus order; a screen-reader story is not designed yet.

## Bugs found in Shift 0.2 and where they went

| 0.2 bug | Cause | 0.3 |
|---|---|---|
| Undo/redo disabled, layers stale, text prompt never opened | `render()` wrote to elements the inspector had destroyed | Structural: React state drives everything; no ID lookups. |
| Image button dead | Ribbon rewrite deleted `#imageInput` | Input lives outside the ribbon; verified by e2e. |
| Moved frame didn't move its present step | Frames existed twice (`frames[]` and objects) | A frame is one object; path steps reference it by id. |
| Frames didn't contain anything | Containment never implemented | `parentId` + `moveObjects` + `autoParent`; verified. |
| Visiting Slide mode stamped slides onto every object | Mode switch mutated all objects | Slide membership is explicit; migration notes the limitation. |

Bugs found *while building* 0.3, caught by the e2e suite or screenshots:
initial fit used a placeholder viewport; a fly-to animation could overwrite a
later camera change; double-click editing broke under pointer capture and again
due to focus theft on mousedown; the phone layout overflowed horizontally.

## What is verified and what is not

**Verified (automated):** 58 unit tests (document model 15, engine 35,
storage 8) and 19 Playwright tests in Chromium covering every ribbon action,
drag/resize/rotate, single-step undo, frame containment, in-place text editing,
all six templates, camera tweening, reduced motion, path editing and multiple
paths, slide operations and notes, frame↔slide conversion, autosave, 120-object
integrity, export/import with images, prototype import, snapshot recovery,
offline reload, tablet/phone layout, and synthetic touch pan/pinch.

**Not verified:** real touch hardware (iPad/Android); Safari and Firefox;
real fullscreen (headless Chromium denies it — the presenter falls back to an
overlay); the low-storage warning; frame rate or memory at scale; long
editing sessions; assistive technology.

## Suggested next milestones

1. Decide rich-text model and grouping model (see gaps 1–2).
2. Object entrance animations + a minimal timeline (then evaluate GSAP).
3. PDF export (one page per slide / per path step) with a regression test on page dimensions.
4. Slide layouts, themes, placeholders.
5. Benchmark at 500 / 2,000 / 10,000 objects on a real tablet; decide on Konva/culling from data.
6. Real-device touch pass (iPad Safari first).
